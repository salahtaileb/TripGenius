import React, { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { User } from '@/api/entities';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserCircle, Route, Sparkles, Settings, LogOut, X, BrainCircuit, Signal, Languages, ImagePlus, Archive, Plane, Bell, Landmark, Car } from 'lucide-react';
import { toast } from 'sonner';

const menuItems = [
  { name: 'Profile', icon: UserCircle, page: 'Profile' },
  { name: 'Notifications', icon: Bell, page: 'Notifications' },
  { name: 'Travel Style Quiz', icon: BrainCircuit, page: 'TravelQuiz' },
  { name: 'Packing Lists', icon: Archive, page: 'PackingLists' },
  { name: 'Create Photo Story', icon: ImagePlus, page: 'CreateStory' },
  { name: 'Expenses Tracker', icon: Landmark, page: 'ExpensesTracker' },
  { name: 'Exchange Rate', icon: Route, page: 'ExchangeRate' },
  { name: 'Order a Cab', icon: Car, page: 'OrderCab' },
  { name: 'Get eSIM', icon: Signal, page: 'GetESIM' },
  { name: 'Translation Manager', icon: Languages, page: 'TranslationsManager' },
  { name: 'Settings', icon: Settings, page: 'Settings' },
];

export default function LeftSidebar({ isOpen, setIsOpen }) {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (isOpen) {
      User.me().then(setUser).catch(() => setUser(null));
    }
  }, [isOpen]);

  const handleLogout = async () => {
    try {
      toast.info("Logging you out...");
      await User.logout();
      setIsOpen(false);
      navigate(createPageUrl('Home'));
      toast.success("You have been logged out.");
    } catch (error) {
      toast.error("Logout failed. Please try again.");
      console.error("Logout error:", error);
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetContent side="left" className="w-80 bg-black text-white border-r border-gray-800 p-0 flex flex-col">
        <SheetHeader className="p-6 border-b border-gray-800 flex flex-row items-center justify-between">
          <Link to={createPageUrl('Profile')} onClick={() => setIsOpen(false)} className="flex items-center gap-4 group">
            <Avatar className="w-12 h-12">
              <AvatarImage src={user?.profile_picture_url} />
              <AvatarFallback className="bg-gray-700">
                 <UserCircle className="w-7 h-7" />
              </AvatarFallback>
            </Avatar>
            
            <div>
              <h3 className="font-bold text-lg text-white group-hover:text-gray-300">
                {user?.full_name || 'Traveler'}
              </h3>
              <p className="text-sm text-gray-400 group-hover:text-gray-300">View Profile</p>
            </div>
          </Link>
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)} className="text-gray-400 hover:bg-gray-800 hover:text-white">
            <X className="w-5 h-5"/>
          </Button>
        </SheetHeader>
        <div className="p-4 flex-1 overflow-y-auto">
          <nav className="flex-1 space-y-1">
            {menuItems.map((item) => (
              <Button
                key={item.name}
                variant="ghost"
                className="w-full justify-start text-md gap-4 h-12 text-gray-300 hover:bg-gray-800 hover:text-white transition-all duration-200 rounded-xl"
                asChild
              >
                <Link to={createPageUrl(item.page)} onClick={() => setIsOpen(false)}>
                  <item.icon className="w-5 h-5" />
                  {item.name}
                </Link>
              </Button>
            ))}
          </nav>
        </div>
        <div className="p-4 mt-auto border-t border-gray-800">
          <Button onClick={handleLogout} variant="ghost" className="w-full justify-start text-md gap-4 h-12 text-gray-400 hover:bg-red-900/50 hover:text-red-400 transition-all duration-200 rounded-xl">
            <LogOut className="w-5 h-5" />
            Logout
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}