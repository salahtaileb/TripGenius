import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Menu, Zap, Briefcase, Bell } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cn } from '@/lib/utils';

export default function TopHeader({ onMenuClick, onBookingClick }) {
  return (
    <header className={cn(
      "p-4 flex justify-between items-center sticky top-0 z-30",
      "bg-gradient-to-r from-indigo-900 via-purple-900 to-slate-900",
      "backdrop-blur-2xl border-b border-purple-700/30 shadow-2xl shadow-purple-900/20"
    )}>
      
      {/* Enhanced Menu Button */}
      <Button 
        variant="ghost" 
        size="icon" 
        onClick={onMenuClick} 
        className={cn(
          "group relative w-12 h-12 rounded-2xl border border-slate-600/50 backdrop-blur-sm",
          "flex items-center justify-center transition-all duration-300 transform hover:scale-105",
          "bg-slate-800/40 hover:bg-slate-700/60 hover:border-sky-400/50 active:scale-95",
          // Subtle glow on hover
          "hover:shadow-[0_0_20px_rgba(14,165,233,0.3)]"
        )}
      >
        <Menu className="w-6 h-6 text-slate-300 group-hover:text-white transition-all duration-300 group-hover:rotate-180" />
        <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-all duration-300 pointer-events-none bg-gradient-to-br from-sky-400 to-violet-500" />
        
        {/* Subtle pulse animation */}
        <div className="absolute inset-0 rounded-2xl border border-sky-400/0 group-hover:border-sky-400/50 transition-all duration-500" />
      </Button>
      
      {/* Enhanced Logo & Brand */}
      <Link to={createPageUrl('Home')} className="flex items-center gap-3 group">
        <div className={cn(
          "relative w-12 h-12 rounded-2xl border-2 backdrop-blur-sm flex items-center justify-center",
          "transition-all duration-500 transform group-hover:scale-110 group-hover:rotate-6",
          "bg-gradient-to-br from-sky-500 via-violet-600 to-pink-500 border-white/20 shadow-xl",
          "hover:shadow-2xl group-hover:shadow-[0_0_30px_rgba(14,165,233,0.6)]"
        )}>
          <Zap className="w-7 h-7 text-white drop-shadow-lg group-hover:drop-shadow-2xl transition-all duration-300" />
          
          {/* Aurora pulse effect */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-sky-400 via-violet-500 to-pink-400 opacity-0 group-hover:opacity-30 transition-opacity duration-500 animate-pulse" />
          
          {/* Rotating border effect */}
          <div className="absolute inset-0 rounded-2xl border-2 border-white/0 group-hover:border-white/40 transition-all duration-300" />
        </div>
        
        <span className={cn(
          "text-2xl font-extrabold tracking-wide transition-all duration-300 text-gradient-aurora",
          "group-hover:drop-shadow-xl"
        )}>
          TripGenius
        </span>
        
      </Link>
      
      <div className="flex items-center gap-2">
        {/* Notification Button */}
        <Link to={createPageUrl('Notifications')}>
          <Button 
            variant="ghost" 
            size="icon" 
            className={cn(
              "group relative w-12 h-12 rounded-2xl border border-slate-600/50 backdrop-blur-sm",
              "flex items-center justify-center transition-all duration-300 transform hover:scale-105",
              "bg-slate-800/40 hover:bg-slate-700/60 hover:border-amber-400/50 active:scale-95",
              // Subtle glow on hover
              "hover:shadow-[0_0_20px_rgba(251,191,36,0.3)]"
            )}
          >
            <Bell className="w-6 h-6 text-slate-300 group-hover:text-white transition-all duration-300 group-hover:animate-swing" />
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-all duration-300 pointer-events-none bg-gradient-to-br from-amber-400 to-orange-500" />
            
            {/* Notification dot */}
            {/* This could be made dynamic in the future */}
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-red-500 to-orange-500 rounded-full border-2 border-slate-900" />
          </Button>
        </Link>
        
        {/* Enhanced Booking Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onBookingClick} 
          className={cn(
            "group relative w-12 h-12 rounded-2xl border border-slate-600/50 backdrop-blur-sm",
            "flex items-center justify-center transition-all duration-300 transform hover:scale-105",
            "bg-slate-800/40 hover:bg-slate-700/60 hover:border-violet-400/50 active:scale-95",
            // Subtle glow on hover
            "hover:shadow-[0_0_20px_rgba(139,92,246,0.3)]"
          )}
        >
          <Briefcase className="w-6 h-6 text-slate-300 group-hover:text-white transition-all duration-300 group-hover:scale-110" />
          <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-all duration-300 pointer-events-none bg-gradient-to-br from-violet-400 to-pink-500" />
        </Button>
      </div>

      {/* Background accent lines */}
      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-purple-600 to-transparent opacity-50" />
      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-sky-400/30 to-transparent" />

      {/* Swing animation for bell */}
      <style>{`
        @keyframes swing {
          20% { transform: rotate(15deg); }
          40% { transform: rotate(-10deg); }
          60% { transform: rotate(5deg); }
          80% { transform: rotate(-5deg); }
          100% { transform: rotate(0deg); }
        }
        .animate-swing:hover {
          animation: swing 0.5s ease-in-out;
        }
      `}</style>
    </header>
  );
}