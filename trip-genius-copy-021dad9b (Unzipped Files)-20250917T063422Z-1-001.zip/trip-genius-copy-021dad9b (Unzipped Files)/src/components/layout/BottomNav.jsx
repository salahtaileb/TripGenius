import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MessageSquare, MapPin, FileText, Plane, Tag } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { 
    name: 'Chat', 
    icon: MessageSquare, 
    page: 'Chat',
    gradient: 'from-sky-400 via-blue-500 to-indigo-600',
    glowColor: 'sky-500',
    activeColor: 'text-sky-400'
  },
  { 
    name: 'Map', 
    icon: MapPin, 
    page: 'Map',
    gradient: 'from-emerald-400 via-teal-500 to-cyan-600',
    glowColor: 'emerald-500',
    activeColor: 'text-emerald-400'
  },
  { 
    name: 'Deals', 
    icon: Tag, 
    page: 'Deals',
    gradient: 'from-violet-400 via-purple-500 to-indigo-600',
    glowColor: 'violet-500',
    activeColor: 'text-violet-400'
  },
  { 
    name: 'Blogs', 
    icon: FileText, 
    page: 'Blogs',
    gradient: 'from-rose-400 via-pink-500 to-purple-600',
    glowColor: 'rose-500',
    activeColor: 'text-pink-400'
  },
  { 
    name: 'Trips', 
    icon: Plane, 
    page: 'MyTrips',
    gradient: 'from-orange-400 via-amber-500 to-yellow-500',
    glowColor: 'orange-500',
    activeColor: 'text-orange-400'
  },
];

export default function BottomNav() {
  const location = useLocation();

  return (
    <nav className={cn(
      "fixed bottom-0 left-0 right-0 z-50",
      "bg-gradient-to-r from-slate-900/97 via-slate-800/97 to-slate-900/97",
      "backdrop-blur-2xl border-t border-slate-700/30 shadow-2xl",
      "before:absolute before:inset-0 before:bg-gradient-to-r before:from-sky-500/5 before:via-transparent before:to-violet-500/5 before:pointer-events-none"
    )}>
      <div className="flex justify-around items-center h-20 px-2">
        {navItems.map((item) => {
          const pageUrl = createPageUrl(item.page);
          const isActive = location.pathname === pageUrl || (item.page === 'Blogs' && location.pathname.startsWith('/BlogPost'));

          return (
            <Link
              key={item.name}
              to={pageUrl}
              className="flex flex-col items-center justify-center w-full h-full group relative"
            >
              {isActive && (
                <div 
                  className={cn(
                    "absolute inset-0 rounded-3xl transition-all duration-700",
                    `bg-gradient-to-r ${item.gradient} opacity-5 blur-xl`
                  )}
                  style={{
                    boxShadow: `0 0 40px rgba(var(--${item.glowColor}), 0.2)`
                  }}
                />
              )}

              <div className={cn(
                "relative w-12 h-12 rounded-2xl border backdrop-blur-sm flex items-center justify-center mb-1",
                "transition-all duration-500 transform group-active:scale-90",
                isActive 
                  ? cn(
                      `bg-gradient-to-br ${item.gradient} border-white/30 shadow-xl scale-110`,
                      `shadow-[0_8px_32px_rgba(var(--${item.glowColor}),0.4)]`
                    )
                  : cn(
                      "bg-slate-800/50 border-slate-600/50 group-hover:border-slate-500/70",
                      "group-hover:bg-slate-700/60 group-hover:scale-105 group-hover:shadow-lg"
                    )
              )}>
                {isActive && (
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                )}

                {isActive && (
                  <div className={cn(
                    "absolute inset-1 rounded-xl opacity-30",
                    `bg-gradient-to-br ${item.gradient}`
                  )} />
                )}

                <item.icon className={cn(
                  "w-6 h-6 transition-all duration-300 relative z-10",
                  isActive 
                    ? 'text-white drop-shadow-lg scale-110' 
                    : 'text-slate-400 group-hover:text-slate-200 group-hover:scale-105'
                )} />

                {isActive && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full shadow-lg animate-pulse" />
                )}
              </div>

              <span className={cn(
                "text-xs font-medium transition-all duration-300 relative z-10",
                isActive 
                  ? cn('text-white font-bold', item.activeColor) 
                  : 'text-slate-500 group-hover:text-slate-300'
              )}>
                {item.name}
              </span>

              {isActive && (
                <div className={cn(
                  "absolute -bottom-1 w-2 h-2 rounded-full transition-all duration-500 shadow-lg",
                  `bg-gradient-to-r ${item.gradient}`
                )} 
                style={{
                  boxShadow: `0 0 15px rgba(var(--${item.glowColor}), 0.8)`
                }}
                />
              )}

              <div className={cn(
                "absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-20 transition-all duration-500 pointer-events-none",
                `bg-gradient-to-br ${item.gradient}`
              )} />

              <div className="absolute inset-0 rounded-3xl bg-white/10 opacity-0 group-active:opacity-100 transition-opacity duration-150 pointer-events-none" />
            </Link>
          );
        })}
      </div>

      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent opacity-50" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-sky-400/30 to-transparent" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-sky-400/20 via-violet-400/20 to-pink-400/20 opacity-60" />
    </nav>
  );
}