
import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { 
  X, Plane, Hotel, Car, MapPin, Sailboat, Package, ExternalLink, ArrowLeft, Building, Users, Star, Scale
} from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const bookingData = {
  main: {
    title: 'Booking Center',
    description: 'Find the best travel deals with our trusted partners.'
  },
  flights: {
    title: 'Search for Flights',
    description: 'Compare prices from top providers.',
    providers: [
      { name: 'Skyscanner', url: 'https://www.skyscanner.com', description: 'Comprehensive flight comparison across hundreds of airlines.' },
      { name: 'Kayak', url: 'https://www.kayak.com/flights', description: 'Search hundreds of travel sites at once for the best deals.' },
      { name: 'Google Flights', url: 'https://www.google.com/flights', description: 'Explore destinations and track prices with smart insights.' },
      { name: 'Momondo', url: 'https://www.momondo.com', description: 'Find and compare cheap flights with colorful insights.' },
    ]
  },
  hotels: {
    title: 'Find Hotels',
    description: 'Book your perfect stay.',
    providers: [
      { name: 'Booking.com', url: 'https://www.booking.com', description: 'The largest selection of accommodations worldwide.' },
      { name: 'Agoda', url: 'https://www.agoda.com', description: 'Great deals on hotels, especially in Asia-Pacific.' },
      { name: 'Expedia', url: 'https://www.expedia.com', description: 'Bundle and save on your complete trip package.' },
      { name: 'Hotels.com', url: 'https://www.hotels.com', description: 'Collect reward nights for free stays - every 10th night free.' },
    ]
  },
  compensation: {
    title: 'Flight Compensation',
    description: 'Get compensation for delayed, cancelled, or overbooked flights.',
    providers: [
      { name: 'CompensAir', url: 'https://www.compensair.com', description: 'Expert flight compensation claims - up to €600 per passenger. No win, no fee.' },
      { name: 'AirHelp', url: 'https://www.airhelp.com', description: 'Leading flight compensation service with global coverage and 98% success rate.' },
      { name: 'ClaimCompass', url: 'https://www.claimcompass.eu', description: 'Free compensation checker for EU flights with instant eligibility results.' },
      { name: 'Flightright', url: 'https://www.flightright.com', description: 'Professional flight delay compensation claims with legal expertise.' },
    ]
  },
};

const mainCategories = [
  { 
    id: 'flights', 
    title: 'Flights', 
    icon: <Plane className="w-8 h-8" />, 
    gradient: 'from-blue-400 via-blue-500 to-indigo-600',
    glowColor: 'blue-500'
  },
  { 
    id: 'hotels', 
    title: 'Hotels', 
    icon: <Hotel className="w-8 h-8" />, 
    gradient: 'from-emerald-400 via-teal-500 to-cyan-600',
    glowColor: 'emerald-500'
  },
  { 
    id: 'compensation', 
    title: 'Compensation', 
    icon: <Scale className="w-8 h-8" />, 
    gradient: 'from-rose-400 via-pink-500 to-purple-600',
    glowColor: 'rose-500'
  },
  { 
    id: 'cars', 
    title: 'Car Rentals', 
    icon: <Car className="w-8 h-8" />, 
    gradient: 'from-violet-400 via-purple-500 to-indigo-600',
    glowColor: 'violet-500',
    url: 'https://www.rentalcars.com' 
  },
  { 
    id: 'activities', 
    title: 'Activities', 
    icon: <MapPin className="w-8 h-8" />, 
    gradient: 'from-orange-400 via-amber-500 to-yellow-500',
    glowColor: 'orange-500',
    url: 'https://www.getyourguide.com' 
  },
  { 
    id: 'cruises', 
    title: 'Cruises', 
    icon: <Sailboat className="w-8 h-8" />, 
    gradient: 'from-cyan-400 via-teal-500 to-blue-600',
    glowColor: 'cyan-500',
    url: 'https://www.cruisedirect.com' 
  },
  { 
    id: 'packages', 
    title: 'Packages', 
    icon: <Package className="w-8 h-8" />, 
    gradient: 'from-indigo-400 via-purple-500 to-pink-600',
    glowColor: 'indigo-500',
    url: 'https://www.expedia.com/packages' 
  },
];

const viewVariants = {
  hidden: { opacity: 0, x: 50 },
  visible: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -50 },
};

export default function BookingDrawer({ isOpen, setIsOpen }) {
  const [view, setView] = useState('main');

  const handleLinkClick = (url) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleSetView = (newView) => {
    const category = mainCategories.find(c => c.id === newView);
    if (category && category.url) {
      handleLinkClick(category.url);
    } else {
      setView(newView);
    }
  };
  
  const currentViewData = bookingData[view] || bookingData.main;

  const renderProviderList = () => (
    <div className="space-y-4">
      {currentViewData.providers.map((provider, index) => (
        <motion.button
          key={provider.name}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          onClick={() => handleLinkClick(provider.url)}
          className="w-full text-left p-5 bg-gradient-to-r from-slate-800/80 to-slate-700/80 backdrop-blur-sm rounded-xl border border-slate-600/50 hover:border-electric-blue/50 flex items-center gap-4 hover:shadow-lg hover:shadow-electric-blue/10 transition-all duration-300 group"
        >
          <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gradient-to-br from-electric-blue/20 to-neon-turquoise/20 border border-electric-blue/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
            <div className="w-6 h-6 rounded-full bg-gradient-aurora"></div>
          </div>
          <div className="flex-grow">
            <h4 className="font-bold text-white text-lg mb-1 group-hover:text-electric-blue transition-colors">{provider.name}</h4>
            <p className="text-sm text-slate-300 leading-relaxed">{provider.description}</p>
          </div>
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-white/10 border border-white/20 flex items-center justify-center group-hover:bg-electric-blue/20 group-hover:border-electric-blue/40 transition-all duration-300">
            <ExternalLink className="w-5 h-5 text-white/70 group-hover:text-white" />
          </div>
        </motion.button>
      ))}
      
      {view === 'compensation' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-8 p-6 bg-gradient-to-br from-slate-800/60 to-slate-900/60 backdrop-blur-sm rounded-xl border border-vivid-purple/30 shadow-lg"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-vivid-purple/20 to-neon-pink/20 border border-vivid-purple/40 flex items-center justify-center">
              <Scale className="w-5 h-5 text-vivid-purple" />
            </div>
            <h4 className="font-bold text-white text-lg">Know Your Rights</h4>
          </div>
          <p className="text-slate-300 mb-4 leading-relaxed">
            You may be entitled to compensation up to <span className="text-electric-blue font-semibold">€600 per passenger</span> for:
          </p>
          <div className="grid grid-cols-1 gap-2 mb-4">
            {[
              'Flight delays of 3+ hours',
              'Flight cancellations',
              'Denied boarding (overbooking)',
              'Missed connections due to delays'
            ].map((item, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-gradient-aurora"></div>
                <span className="text-sm text-slate-300">{item}</span>
              </div>
            ))}
          </div>
          <div className="p-3 bg-slate-700/50 rounded-lg border border-slate-600/50">
            <p className="text-xs text-slate-400 leading-relaxed">
              <span className="text-neon-turquoise font-medium">EU Regulation 261/2004:</span> Applies to flights departing from EU or with EU airlines arriving in EU.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );

  const renderMainGrid = () => (
    <div className="grid grid-cols-2 gap-4">
      {mainCategories.map((item, index) => (
        <motion.button
          key={item.title}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
          onClick={() => handleSetView(item.id)}
          className={`group relative p-6 flex flex-col items-center justify-center rounded-2xl text-white font-bold transition-all duration-300 transform hover:scale-105 bg-gradient-to-br ${item.gradient} border border-white/20 hover:border-white/40 shadow-lg hover:shadow-xl backdrop-blur-sm overflow-hidden`}
          style={{
            boxShadow: `0 8px 32px rgba(0,0,0,0.3), 0 0 20px rgba(var(--${item.glowColor}), 0.3)`
          }}
        >
          {/* Aurora background effect */}
          <div className="absolute inset-0 bg-gradient-aurora opacity-0 group-hover:opacity-20 transition-opacity duration-500"></div>
          
          {/* Icon container with frame */}
          <div className="relative w-16 h-16 rounded-full border-2 border-white/30 bg-white/10 backdrop-blur-sm flex items-center justify-center mb-3 group-hover:border-white/50 group-hover:bg-white/20 transition-all duration-300 group-hover:scale-110">
            <div className="absolute inset-0 rounded-full bg-gradient-aurora opacity-0 group-hover:opacity-30 transition-opacity duration-300"></div>
            {item.icon}
          </div>
          
          <span className="text-lg font-bold text-center leading-tight relative z-10">{item.title}</span>
          
          {/* External link indicator */}
          <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-white/10 border border-white/20 flex items-center justify-center opacity-60 group-hover:opacity-100 group-hover:bg-white/20 transition-all duration-300">
            <ExternalLink className="w-3 h-3" />
          </div>
          
          {/* Shimmer effect */}
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent transition-transform duration-1000 ease-out"></div>
        </motion.button>
      ))}
    </div>
  );

  return (
    <Sheet open={isOpen} onOpenChange={(open) => {
      setIsOpen(open);
      if (!open) setTimeout(() => setView('main'), 300);
    }}>
      <SheetContent side="right" className="w-[90vw] max-w-md bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white border-l-0 p-0 flex flex-col backdrop-blur-xl">
        {/* Header with aurora styling */}
        <SheetHeader className="p-6 border-b border-slate-700/50 backdrop-blur-sm bg-slate-800/30 flex flex-row items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            {view !== 'main' && (
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setView('main')} 
                className={cn(
                  "group relative w-12 h-12 rounded-2xl border-2 backdrop-blur-sm flex items-center justify-center transition-all duration-300 transform",
                  "bg-slate-800/50 border-slate-600/50 hover:border-vivid-purple/50 hover:bg-slate-700/50 hover:scale-105"
                )}
              >
                <ArrowLeft className="w-5 h-5 text-slate-300 group-hover:text-vivid-purple transition-colors" />
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-all duration-300 pointer-events-none bg-gradient-to-br from-vivid-purple to-neon-pink" />
              </Button>
            )}
            <div>
              <SheetTitle className="text-white text-xl font-bold bg-gradient-to-r from-white to-slate-200 bg-clip-text">
                {currentViewData.title}
              </SheetTitle>
              <SheetDescription className="text-slate-300 mt-1">
                {currentViewData.description}
              </SheetDescription>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsOpen(false)} 
            className="text-slate-300 hover:bg-slate-700/50 hover:text-white border border-slate-600/50 hover:border-red-400/50 transition-all duration-300"
          >
            <X className="w-5 h-5"/>
          </Button>
        </SheetHeader>

        {/* Main content area */}
        <div className="flex-grow overflow-y-auto p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              variants={viewVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
              transition={{ duration: 0.3 }}
            >
              {view === 'main' ? renderMainGrid() : renderProviderList()}
            </motion.div>
          </AnimatePresence>
        </div>
        
        {/* Footer with aurora styling */}
        <div className="p-4 bg-slate-800/50 backdrop-blur-sm border-t border-slate-700/50 flex-shrink-0 mt-auto">
          <div className="p-3 rounded-lg border border-slate-600/30 bg-slate-700/30">
            <p className="text-xs text-slate-300 text-center leading-relaxed">
              <span className="text-electric-blue font-semibold">Disclosure:</span> TripGenius may earn a commission from partners. This helps us keep the app free for travelers worldwide.
            </p>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
