import { useState, useEffect } from 'react';
import { Translation } from '@/api/entities';
import { User } from '@/api/entities';

export const useTranslation = () => {
  const [translations, setTranslations] = useState({});
  const [currentLanguage, setCurrentLanguage] = useState('en');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const initializeTranslations = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        const userLang = user?.preferred_language || 'en';
        setCurrentLanguage(userLang);

        const translationRecords = await Translation.list();
        const translationsMap = translationRecords.reduce((acc, item) => {
          if (!acc[item.lang]) {
            acc[item.lang] = {};
          }
          acc[item.lang][item.key] = item.value;
          return acc;
        }, {});
        
        setTranslations(translationsMap);
      } catch (error) {
        console.error('Failed to load translations:', error);
      }
      setIsLoading(false);
    };

    initializeTranslations();
  }, []);

  const t = (key, fallback = key) => {
    if (currentLanguage === 'en') {
      return fallback;
    }
    
    if (translations[currentLanguage] && translations[currentLanguage][key]) {
      return translations[currentLanguage][key];
    }
    
    return fallback;
  };

  return { t, currentLanguage, isLoading };
};