import React from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, MapPin, Users, ArrowRight, Share2, Sparkles, Trash2, Star, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';

export default function TripCard({ trip, onDelete }) {
  const formatDate = (dateString) => {
    if (!dateString) return 'TBD';
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: new Date(dateString).getFullYear() !== new Date().getFullYear() ? 'numeric' : undefined
    });
  };

  const getStatusStyles = (status) => {
    switch (status) {
      case 'planning': 
        return {
          badge: 'bg-blue-50 text-blue-700 border-blue-200',
          icon: Clock,
          color: 'text-blue-600'
        };
      case 'booked': 
        return {
          badge: 'bg-green-50 text-green-700 border-green-200',
          icon: Star,
          color: 'text-green-600'
        };
      case 'completed': 
        return {
          badge: 'bg-purple-50 text-purple-700 border-purple-200',
          icon: Sparkles,
          color: 'text-purple-600'
        };
      default: 
        return {
          badge: 'bg-gray-50 text-gray-700 border-gray-200',
          icon: Clock,
          color: 'text-gray-600'
        };
    }
  };

  const getBudgetStyles = (budget) => {
    switch (budget) {
      case 'budget':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'mid-range':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'luxury':
        return 'bg-rose-50 text-rose-700 border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  const handleDelete = (e) => {
    e.stopPropagation();
    e.preventDefault();
    onDelete(trip.id);
  };

  const statusConfig = getStatusStyles(trip.status);
  const StatusIcon = statusConfig.icon;

  return (
    <Card className={cn(
      "group relative overflow-hidden rounded-3xl border-0 transition-all duration-500 transform hover:scale-105 hover:-translate-y-2",
      "bg-white/80 backdrop-blur-sm shadow-lg hover:shadow-2xl",
      "cursor-pointer active:scale-95"
    )}>
      {/* Enhanced image section */}
      <div className="h-52 relative overflow-hidden">
        <img 
          src={trip.cover_image_url || 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=800&q=80'}
          alt={trip.name}
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-all duration-700"
          loading="lazy"
        />
        
        {/* Enhanced gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent group-hover:from-black/80 transition-all duration-500"></div>
        
        {/* Floating elements */}
        <div className="absolute top-4 left-4 flex flex-wrap gap-2">
          {trip.is_template && (
            <Badge className={cn(
              "bg-black/40 backdrop-blur-md text-white border border-white/20 font-medium",
              "shadow-lg hover:bg-black/50 transition-all duration-300"
            )}>
              <Sparkles className="w-3 h-3 mr-1" />
              Template
            </Badge>
          )}
          
          {trip.generated_by_ai && (
            <Badge className={cn(
              "bg-violet-500/40 backdrop-blur-md text-white border border-violet-400/30 font-medium",
              "shadow-lg hover:bg-violet-500/50 transition-all duration-300"
            )}>
              AI Generated
            </Badge>
          )}
        </div>

        {/* Enhanced bottom content */}
        <div className="absolute bottom-4 left-4 right-4 text-white">
          <div className="flex items-center gap-2 mb-2 opacity-90">
            <MapPin className="w-4 h-4 flex-shrink-0" />
            <span className="text-sm font-medium truncate">{trip.destination}</span>
          </div>
          <h3 className="font-bold text-xl leading-tight mb-1 group-hover:text-yellow-300 transition-colors duration-300">
            {trip.name}
          </h3>
        </div>

        {/* Subtle corner accent */}
        <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-bl from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>
      
      {/* Enhanced content section */}
      <CardHeader className="pb-3 pt-5 bg-white/95 backdrop-blur-sm">
        <div className="flex items-start justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className={cn(statusConfig.badge, "font-medium shadow-sm")}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {trip.status.charAt(0).toUpperCase() + trip.status.slice(1)}
            </Badge>
            {trip.budget && (
              <Badge variant="outline" className={cn(getBudgetStyles(trip.budget), "font-medium shadow-sm")}>
                {trip.budget.charAt(0).toUpperCase() + trip.budget.slice(1)}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0 pb-6 bg-white/95 backdrop-blur-sm">
        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="font-medium">
              {formatDate(trip.start_date)} - {formatDate(trip.end_date)}
            </span>
          </div>
          
          {trip.travelers && (
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Users className="w-4 h-4 text-slate-500" />
              <span className="font-medium">
                {trip.travelers} {trip.travelers === 1 ? 'traveler' : 'travelers'}
              </span>
            </div>
          )}
        </div>

        {/* Enhanced action buttons */}
        <div className="flex gap-3">
          <Link to={createPageUrl(`ViewItinerary?id=${trip.id}`)} className="flex-1">
            <Button 
              variant="outline" 
              size="sm" 
              className={cn(
                "w-full group/btn transition-all duration-300 transform hover:scale-105 active:scale-95",
                "border-slate-300 text-slate-700 hover:bg-slate-900 hover:text-white hover:border-slate-900",
                "shadow-sm hover:shadow-lg font-medium"
              )}
            >
              <span className="mr-2">View Details</span>
              <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
            </Button>
          </Link>
          
          <div className="flex gap-2">
            {trip.is_template && (
              <Button 
                variant="outline" 
                size="sm" 
                className={cn(
                  "transition-all duration-300 transform hover:scale-105 active:scale-95",
                  "border-blue-200 text-blue-600 hover:bg-blue-50 hover:border-blue-300",
                  "shadow-sm hover:shadow-md"
                )}
              >
                <Share2 className="w-4 h-4" />
              </Button>
            )}
            
            {onDelete && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleDelete}
                className={cn(
                  "transition-all duration-300 transform hover:scale-105 active:scale-95",
                  "border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300",
                  "shadow-sm hover:shadow-md"
                )}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>

      {/* Subtle hover border effect */}
      <div className="absolute inset-0 rounded-3xl border-2 border-transparent group-hover:border-slate-200/50 transition-all duration-500 pointer-events-none" />
      
      {/* Subtle inner glow on hover */}
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-sky-400/0 via-transparent to-violet-400/0 group-hover:from-sky-400/5 group-hover:to-violet-400/5 transition-all duration-700 pointer-events-none" />
    </Card>
  );
}