import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Cookie, X } from 'lucide-react';

export default function CookieConsent() {
  const [showConsent, setShowConsent] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookieConsent');
    if (!consent) {
      setShowConsent(true);
    }
  }, []);

  const acceptCookies = () => {
    localStorage.setItem('cookieConsent', 'accepted');
    setShowConsent(false);
    // Reload to apply scripts if they weren't loaded initially
    window.location.reload();
  };

  const declineCookies = () => {
    localStorage.setItem('cookieConsent', 'declined');
    setShowConsent(false);
    // Disable GA if declined
    if (typeof window.gtag === 'function') {
      window.gtag('consent', 'update', {
        analytics_storage: 'denied'
      });
    }
  };

  if (!showConsent) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:max-w-md md:left-auto">
      <Card className="bg-white border-slate-200 shadow-xl">
        <CardContent className="p-4">
          <div className="flex items-start gap-4">
            <Cookie className="w-8 h-8 text-slate-700 flex-shrink-0 mt-1" />
            <div className="flex-1">
              <h3 className="font-bold text-dark-text mb-1">We value your privacy</h3>
              <p className="text-sm text-medium-text mb-4">
                We use cookies to improve our service and for analytics. By clicking "Accept", you agree to our use of these technologies.
              </p>
              <div className="flex gap-2 flex-wrap">
                <Button onClick={acceptCookies} size="sm" className="bg-slate-900 text-white hover:bg-slate-800">
                  Accept
                </Button>
                <Button onClick={declineCookies} variant="outline" size="sm">
                  Decline
                </Button>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={declineCookies}
              className="text-slate-500 hover:text-slate-800 flex-shrink-0 -mt-2 -mr-2"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}