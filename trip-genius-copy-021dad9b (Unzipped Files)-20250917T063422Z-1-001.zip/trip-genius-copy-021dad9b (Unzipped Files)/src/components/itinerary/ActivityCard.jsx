import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Tag, DollarSign, ExternalLink, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ActivityCard({ activity }) {
  const categoryColors = {
    sightseeing: "bg-blue-100 text-blue-800",
    activity: "bg-green-100 text-green-800",
    restaurant: "bg-orange-100 text-orange-800",
    shopping: "bg-pink-100 text-pink-800",
    transport: "bg-purple-100 text-purple-800",
    accommodation: "bg-indigo-100 text-indigo-800",
  };

  return (
    <Card className="bg-white border-light-surface-2 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="grid md:grid-cols-3">
        {activity.image_url && (
          <div className="md:col-span-1">
            <img src={activity.image_url} alt={activity.name} className="w-full h-40 md:h-full object-cover" />
          </div>
        )}
        <div className="md:col-span-2">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div>
                <Badge className={`${categoryColors[activity.category] || 'bg-gray-100 text-gray-800'} mb-2`}>
                  {activity.category}
                </Badge>
                <h3 className="font-bold text-lg text-dark-text">{activity.name}</h3>
              </div>
              {activity.time && (
                <div className="flex items-center gap-2 text-sm text-medium-text bg-light-surface px-2 py-1 rounded-md">
                  <Clock className="w-4 h-4" />
                  <span>{activity.time}</span>
                </div>
              )}
            </div>
            <p className="text-sm text-accent-text mt-2">{activity.description}</p>
            
            <div className="flex flex-wrap gap-4 mt-4 text-sm text-medium-text">
              {activity.cost && (
                <div className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" /> <span>{activity.cost}</span>
                </div>
              )}
              {activity.location && (
                 <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" /> <span>{activity.location}</span>
                </div>
              )}
            </div>

            {activity.booking_url && (
              <div className="mt-4">
                <a href={activity.booking_url} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm">
                    View Details
                    <ExternalLink className="w-4 h-4 ml-2" />
                  </Button>
                </a>
              </div>
            )}
          </CardContent>
        </div>
      </div>
    </Card>
  );
}