import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Clock, DollarSign, Star } from 'lucide-react';

export default function ItineraryOverview({ trip }) {
  if (!trip.overview) return null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main description */}
      <Card className="lg:col-span-2 bg-white border border-gray-200">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-dark-text">About This Trip</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-medium-text leading-relaxed mb-4">
            {trip.overview.description || 'No description available.'}
          </p>
          
          {trip.overview.highlights && trip.overview.highlights.length > 0 && (
            <div>
              <h3 className="font-semibold text-dark-text mb-3">Trip Highlights</h3>
              <ul className="space-y-2">
                {trip.overview.highlights.map((highlight, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Star className="w-4 h-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                    <span className="text-medium-text">{highlight}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Trip details sidebar */}
      <Card className="bg-white border border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-dark-text">Trip Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {trip.overview.currency && (
            <div className="flex items-center gap-3">
              <DollarSign className="w-5 h-5 text-green-600" />
              <div>
                <p className="font-medium text-dark-text">Currency</p>
                <p className="text-sm text-medium-text">{trip.overview.currency}</p>
              </div>
            </div>
          )}
          
          {trip.overview.language && (
            <div className="flex items-center gap-3">
              <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-xs text-white font-bold">L</span>
              </div>
              <div>
                <p className="font-medium text-dark-text">Language</p>
                <p className="text-sm text-medium-text">{trip.overview.language}</p>
              </div>
            </div>
          )}
          
          {trip.overview.time_zone && (
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-purple-600" />
              <div>
                <p className="font-medium text-dark-text">Time Zone</p>
                <p className="text-sm text-medium-text">{trip.overview.time_zone}</p>
              </div>
            </div>
          )}
          
          {trip.overview.best_time_to_visit && (
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-orange-600" />
              <div>
                <p className="font-medium text-dark-text">Best Time to Visit</p>
                <p className="text-sm text-medium-text">{trip.overview.best_time_to_visit}</p>
              </div>
            </div>
          )}

          {/* Trip status and budget badges */}
          <div className="pt-4 border-t">
            <div className="flex flex-wrap gap-2">
              {trip.status && (
                <Badge variant="outline" className="capitalize">
                  {trip.status}
                </Badge>
              )}
              {trip.budget && (
                <Badge variant="outline" className="capitalize">
                  {trip.budget}
                </Badge>
              )}
              {trip.generated_by_ai && (
                <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                  AI Generated
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}