import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import HotelCard from './HotelCard';

export default function HotelRecommendations({ hotels }) {
  if (!hotels || hotels.length === 0) {
    return (
      <Card>
        <CardContent className="p-6 text-center text-medium-text">
          No hotel recommendations have been added yet.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
      {hotels.map((hotel, index) => (
        <HotelCard key={index} hotel={hotel} />
      ))}
    </div>
  );
}