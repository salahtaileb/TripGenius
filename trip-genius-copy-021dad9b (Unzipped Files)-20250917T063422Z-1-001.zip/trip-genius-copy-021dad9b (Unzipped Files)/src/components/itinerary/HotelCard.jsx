import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Star, DollarSign, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function HotelCard({ hotel }) {
  return (
    <Card className="bg-white border-light-surface-2 overflow-hidden shadow-sm hover:shadow-md transition-shadow h-full flex flex-col">
      {hotel.image_urls && hotel.image_urls.length > 0 && (
        <img src={hotel.image_urls[0]} alt={hotel.name} className="w-full h-48 object-cover" />
      )}
      <CardContent className="p-4 flex-1 flex flex-col">
        <h3 className="font-bold text-lg text-dark-text">{hotel.name}</h3>
        {hotel.star_rating && (
          <div className="flex items-center gap-1 text-yellow-500 my-2">
            {Array.from({ length: 5 }, (_, i) => (
              <Star key={i} className={`w-4 h-4 ${i < hotel.star_rating ? 'fill-current' : 'text-gray-300'}`} />
            ))}
          </div>
        )}
        <p className="text-sm text-accent-text mt-1 flex-1">{hotel.why_recommended}</p>
        
        {hotel.price_range && (
           <Badge variant="outline" className="my-3 w-fit">{hotel.price_range}</Badge>
        )}

        {hotel.booking_url && (
          <div className="mt-auto pt-4">
            <a href={hotel.booking_url} target="_blank" rel="noopener noreferrer" className="w-full">
              <Button variant="outline" className="w-full">
                Check Prices
                <ExternalLink className="w-4 h-4 ml-2" />
              </Button>
            </a>
          </div>
        )}
      </CardContent>
    </Card>
  );
}