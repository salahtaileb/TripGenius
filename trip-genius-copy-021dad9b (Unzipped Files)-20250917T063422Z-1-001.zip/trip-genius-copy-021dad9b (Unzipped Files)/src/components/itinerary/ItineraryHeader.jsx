import React from 'react';
import { Calendar, Users, MapPin, Share2, Edit, Trash2, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ItineraryHeader({ trip }) {
  const navigate = useNavigate();
  
  const formatDate = (dateString) => {
    if (!dateString) return 'Date TBD';
    return new Date(dateString).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getTripDuration = () => {
    if (!trip.start_date || !trip.end_date) return '';
    const start = new Date(trip.start_date);
    const end = new Date(trip.end_date);
    const diffTime = Math.abs(end - start);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays === 1 ? '1 day' : `${diffDays} days`;
  };

  return (
    <header className="relative h-64 md:h-96 w-full">
      <img
        src={trip.cover_image_url || 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1'}
        alt={trip.name}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
      
      {/* Back button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate(-1)}
        className="absolute top-4 left-4 bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 border border-white/20"
      >
        <ArrowLeft className="w-5 h-5" />
      </Button>

      {/* Action buttons */}
      <div className="absolute top-4 right-4 flex gap-2">
        <Button variant="ghost" size="icon" className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 border border-white/20">
          <Share2 className="w-5 h-5" />
        </Button>
        <Button variant="ghost" size="icon" className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 border border-white/20">
          <Edit className="w-5 h-5" />
        </Button>
      </div>
      
      {/* Trip info overlay */}
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 text-white">
        <h1 className="text-2xl md:text-4xl font-bold mb-2">{trip.name}</h1>
        <div className="flex flex-wrap items-center gap-4 text-sm md:text-base">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            <span>{trip.destination}</span>
          </div>
          {(trip.start_date || trip.end_date) && (
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>
                {trip.start_date && trip.end_date 
                  ? `${formatDate(trip.start_date)} - ${formatDate(trip.end_date)}`
                  : formatDate(trip.start_date || trip.end_date)
                }
              </span>
            </div>
          )}
          {getTripDuration() && (
            <span className="text-white/80">({getTripDuration()})</span>
          )}
          {trip.travelers && (
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span>{trip.travelers} {trip.travelers === 1 ? 'traveler' : 'travelers'}</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}