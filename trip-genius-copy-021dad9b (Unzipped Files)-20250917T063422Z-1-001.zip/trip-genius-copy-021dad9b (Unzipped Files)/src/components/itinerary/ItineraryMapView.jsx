import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { getMapboxToken } from '@/api/functions';
import { Loader2 } from 'lucide-react';

export default function ItineraryMapView({ trip }) {
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchToken = async () => {
      try {
        const response = await getMapboxToken();
        if (response.data.token) {
          setToken(response.data.token);
        }
      } catch (error) {
        console.error("Failed to get mapbox token", error);
      } finally {
        setLoading(false);
      }
    };
    fetchToken();
  }, []);

  const locations = [];
  trip.daily_itinerary?.forEach(day => {
    day.activities?.forEach(activity => {
      if (activity.latitude && activity.longitude) {
        locations.push({
          lat: activity.latitude,
          lng: activity.longitude,
          name: activity.name,
          type: 'Activity',
        });
      }
    });
  });

  trip.hotels?.forEach(hotel => {
    if (hotel.latitude && hotel.longitude) {
      locations.push({
        lat: hotel.latitude,
        lng: hotel.longitude,
        name: hotel.name,
        type: 'Hotel',
      });
    }
  });

  const centerLat = trip.latitude || (locations.length > 0 ? locations[0].lat : 51.505);
  const centerLng = trip.longitude || (locations.length > 0 ? locations[0].lng : -0.09);

  if (loading) {
    return <div className="flex items-center justify-center h-full bg-light-surface"><Loader2 className="animate-spin" /></div>;
  }

  if (!token) {
    return <div className="flex items-center justify-center h-full bg-light-surface">Map could not be loaded.</div>;
  }
  
  return (
    <MapContainer center={[centerLat, centerLng]} zoom={12} scrollWheelZoom={false} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        url={`https://api.mapbox.com/styles/v1/mapbox/streets-v11/tiles/{z}/{x}/{y}?access_token=${token}`}
        attribution='&copy; <a href="https://www.mapbox.com/about/maps/">Mapbox</a> &copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      />
      {locations.map((loc, index) => (
        <Marker key={index} position={[loc.lat, loc.lng]}>
          <Popup>
            <strong>{loc.name}</strong><br/>
            <span className="text-xs">{loc.type}</span>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}