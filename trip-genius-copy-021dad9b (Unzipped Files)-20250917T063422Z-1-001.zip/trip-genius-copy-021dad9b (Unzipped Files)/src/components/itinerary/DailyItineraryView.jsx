import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import ActivityCard from './ActivityCard';

export default function DailyItineraryView({ itinerary }) {
  if (!itinerary || itinerary.length === 0) {
    return (
      <Card className="bg-white border border-gray-200">
        <CardContent className="p-8 text-center">
          <p className="text-medium-text">No daily itinerary available for this trip.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {itinerary.map((day) => (
        <Card key={day.day} className="bg-white border border-gray-200 overflow-hidden">
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-bold text-dark-text">
                Day {day.day}
                {day.title && <span className="text-medium-text font-normal ml-2">• {day.title}</span>}
              </CardTitle>
              {day.date && (
                <span className="text-sm text-medium-text">
                  {new Date(day.date).toLocaleDateString(undefined, { 
                    weekday: 'short', 
                    month: 'short', 
                    day: 'numeric' 
                  })}
                </span>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {day.activities && day.activities.length > 0 ? (
              <div className="divide-y divide-gray-100">
                {day.activities.map((activity, index) => (
                  <ActivityCard key={index} activity={activity} />
                ))}
              </div>
            ) : (
              <div className="p-6 text-center text-medium-text">
                No activities planned for this day.
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}