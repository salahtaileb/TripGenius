import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Bell, Palette, Shield, Trash2, ArrowLeft, FileText } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';

export default function SettingsPage() {
    const navigate = useNavigate();

    return (
        <div className="p-6 bg-gradient-to-b from-slate-50 to-slate-100 min-h-full pb-32">
            <div className="flex items-center gap-4 mb-6">
                <Button variant="outline" size="icon" className="border-gray-300 text-slate-700 hover:bg-slate-200" onClick={() => navigate(-1)}>
                    <ArrowLeft className="w-4 h-4" />
                </Button>
                <h1 className="text-3xl font-bold text-slate-800">Settings</h1>
            </div>

            <div className="max-w-2xl mx-auto space-y-8">
                <Card className="bg-white/90 backdrop-blur-sm border-gray-200/50 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-slate-800">Notifications</CardTitle>
                        <CardDescription>Manage how you receive notifications.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="push-notifications" className="flex items-center gap-3 text-slate-700">
                                <Bell className="w-5 h-5"/>
                                <span>Push Notifications</span>
                            </Label>
                            <Switch id="push-notifications" />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-white/90 backdrop-blur-sm border-gray-200/50 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-slate-800">Appearance</CardTitle>
                        <CardDescription>Customize the look and feel of the app.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="dark-mode" className="flex items-center gap-3 text-slate-700">
                                <Palette className="w-5 h-5"/>
                                <span>Dark Mode (Coming Soon)</span>
                            </Label>
                            <Switch id="dark-mode" disabled />
                        </div>
                    </CardContent>
                </Card>

                <Card className="bg-white/90 backdrop-blur-sm border-gray-200/50 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-slate-800">Legal & Privacy</CardTitle>
                        <CardDescription>Review our policies and terms.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Link to={createPageUrl('PrivacyPolicy')}>
                            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 cursor-pointer">
                                <span className="flex items-center gap-3 text-slate-700">
                                    <Shield className="w-5 h-5"/>
                                    <span>Privacy Policy</span>
                                </span>
                            </div>
                        </Link>
                        <Link to={createPageUrl('TermsConditions')}>
                            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-100 cursor-pointer">
                                <span className="flex items-center gap-3 text-slate-700">
                                    <FileText className="w-5 h-5"/>
                                    <span>Terms & Conditions</span>
                                </span>
                            </div>
                        </Link>
                    </CardContent>
                </Card>

                <Card className="bg-white/90 backdrop-blur-sm border-red-500/20 shadow-lg">
                    <CardHeader>
                        <CardTitle className="text-red-700">Account</CardTitle>
                        <CardDescription>Manage your account settings.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                         <Link to={createPageUrl('DeleteAccount')}>
                            <div className="flex items-center justify-between p-3 rounded-lg hover:bg-red-50 cursor-pointer">
                                <span className="flex items-center gap-3 text-red-600">
                                    <Trash2 className="w-5 h-5"/>
                                    <span>Delete Account</span>
                                </span>
                            </div>
                        </Link>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}