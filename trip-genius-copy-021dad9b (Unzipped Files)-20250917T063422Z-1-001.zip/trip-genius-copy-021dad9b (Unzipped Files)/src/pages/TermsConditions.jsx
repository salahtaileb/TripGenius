
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Calendar, ArrowLeft } from 'lucide-react';

export default function TermsConditionsPage() {
  const navigate = useNavigate();

  return (
    <div className="p-6 bg-soft-white min-h-full">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" className="border-gray-300 text-dark-readable hover:bg-light-grey" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex items-center gap-3">
            <FileText className="w-8 h-8 text-electric-blue" />
            <h1 className="text-3xl font-bold text-dark-readable">Terms & Conditions</h1>
          </div>
        </div>

        <Card className="bg-glass border border-electric-blue/20">
          <CardHeader>
            <div className="flex items-center gap-2 text-sm text-medium-grey mb-2">
              <Calendar className="w-4 h-4" />
              Last updated: January 2024
            </div>
            <CardTitle className="text-dark-readable">TripGenius Terms of Service</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose max-w-none text-medium-grey [&_h3]:text-dark-readable [&_h3]:font-semibold [&_h3]:mb-3 [&_h3]:text-lg [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:ml-6 [&_ul]:mt-2 space-y-6">
              <section>
                <h3>1. Acceptance of Terms</h3>
                <p>
                  By accessing and using TripGenius ("the Service"), you accept and agree to be bound by the terms 
                  and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                </p>
              </section>

              <section>
                <h3>2. Use License</h3>
                <p>
                  Permission is granted to temporarily download one copy of TripGenius per device for personal, 
                  non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
                </p>
                <ul>
                  <li>modify or copy the materials</li>
                  <li>use the materials for any commercial purpose or for any public display</li>
                  <li>attempt to reverse engineer any software contained in TripGenius</li>
                  <li>remove any copyright or other proprietary notations from the materials</li>
                </ul>
              </section>

              <section>
                <h3>3. Travel Booking Services</h3>
                <p>
                  TripGenius acts as an intermediary between users and third-party travel service providers. 
                  We are not responsible for the actual provision of travel services, including but not limited to:
                </p>
                <ul>
                  <li>Flight delays, cancellations, or changes</li>
                  <li>Hotel availability and service quality</li>
                  <li>Car rental conditions and availability</li>
                  <li>Activity bookings and experience quality</li>
                </ul>
              </section>

              <section>
                <h3>4. Affiliate Relationships</h3>
                <p>
                  TripGenius may earn commissions from bookings made through our affiliate links. 
                  This does not affect the price you pay for services, but helps us maintain and improve our platform.
                </p>
              </section>

              <section>
                <h3>5. User Content</h3>
                <p>
                  By submitting content to TripGenius (including trip plans, reviews, and photos), you grant us 
                  a non-exclusive, worldwide, royalty-free license to use, modify, and display such content 
                  for the purpose of providing and promoting our services.
                </p>
              </section>

              <section>
                <h3>6. Privacy Policy</h3>
                <p>
                  Your privacy is important to us. Our Privacy Policy explains how we collect, use, and protect 
                  your information when you use our Service. By using our Service, you agree to the collection 
                  and use of information in accordance with our Privacy Policy.
                </p>
              </section>

              <section>
                <h3>7. Limitation of Liability</h3>
                <p>
                  In no event shall TripGenius or its suppliers be liable for any damages (including, without limitation, 
                  damages for loss of data or profit, or due to business interruption) arising out of the use or inability 
                  to use TripGenius, even if TripGenius or a TripGenius authorized representative has been notified 
                  orally or in writing of the possibility of such damage.
                </p>
              </section>

              <section>
                <h3>8. Changes to Terms</h3>
                <p>
                  We reserve the right to revise these terms of service at any time without notice. 
                  By using TripGenius, you are agreeing to be bound by the then current version of these terms of service.
                </p>
              </section>

              <section>
                <h3>9. Contact Information</h3>
                <p>
                  If you have any questions about these Terms & Conditions, please contact us at legal@tripgenius.com
                </p>
              </section>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
