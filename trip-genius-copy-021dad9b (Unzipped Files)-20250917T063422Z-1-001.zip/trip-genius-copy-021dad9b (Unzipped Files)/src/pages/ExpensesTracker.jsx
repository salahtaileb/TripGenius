import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate, Link, useSearchParams } from 'react-router-dom';
import { Trip } from '@/api/entities';
import { Expense } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  ArrowLeft, Plus, Trash2, Edit, Save, X, BrainCircuit, Loader2,
  Landmark, Plane, Hotel, UtensilsCrossed, MountainSnow, BusFront, ShoppingBag, Lightbulb,
  AlertCircle, PieChart, FileQuestion, ChevronRight, TrendingUp
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, Cell } from 'recharts';
import { analyzeExpenses } from '@/api/functions';


const categoryIcons = {
  "Flights": <Plane className="w-5 h-5" />,
  "Hotels": <Hotel className="w-5 h-5" />,
  "Food": <UtensilsCrossed className="w-5 h-5" />,
  "Activities": <MountainSnow className="w-5 h-5" />,
  "Transport": <BusFront className="w-5 h-5" />,
  "Misc": <ShoppingBag className="w-5 h-5" />,
};
const categories = Object.keys(categoryIcons);

const categoryColors = {
  Flights: '#3b82f6', // blue-500
  Hotels: '#8b5cf6', // violet-500
  Food: '#10b981',   // emerald-500
  Activities: '#f97316', // orange-500
  Transport: '#f59e0b', // amber-500
  Misc: '#64748b',   // slate-500
};

export default function ExpensesTracker() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const tripId = searchParams.get('tripId');

  const [trips, setTrips] = useState([]);
  const [trip, setTrip] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const [formState, setFormState] = useState({
    name: '',
    amount: '',
    category: 'Food',
    date: new Date().toISOString().split('T')[0],
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [expenseToDelete, setExpenseToDelete] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      setError(null);
      
      if (tripId) {
        // A trip is selected, load its data
        try {
          const tripData = await Trip.get(tripId);
          if (!tripData) {
            throw new Error("Trip not found.");
          }
          setTrip(tripData);
          const expenseData = await Expense.filter({ trip_id: tripId }, '-date');
          setExpenses(expenseData || []);
        } catch (e) {
          setError("Failed to load trip data. The trip may have been deleted or does not exist.");
          toast.error("Could not load trip data.");
          setTrip(null); // Clear trip state if loading failed
          setSearchParams({}); // Clear tripId from URL to show selection
        }
      } else {
        // No trip selected, load all trips for selection
        try {
          const userTrips = await Trip.list('-created_date');
          setTrips(userTrips || []);
        } catch (e) {
          setError("Failed to load your list of trips.");
          toast.error("Could not load your trips.");
          setTrips([]);
        }
      }
      setIsLoading(false);
    };

    loadData();
  }, [tripId, setSearchParams]);

  const expensesByCategory = useMemo(() => {
    const totals = categories.reduce((acc, cat) => ({ ...acc, [cat]: 0 }), {});
    expenses.forEach(exp => {
      if (totals[exp.category] !== undefined) {
        totals[exp.category] += exp.amount;
      }
    });
    return Object.entries(totals)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [expenses]);

  const totalSpent = useMemo(() => {
    return expenses.reduce((sum, exp) => sum + exp.amount, 0);
  }, [expenses]);

  const handleInputChange = useCallback((e) => {
    const { name, value } = e.target;
    setFormState(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleSelectChange = useCallback((value) => {
    setFormState(prev => ({ ...prev, category: value }));
  }, []);

  const handleAddExpense = async (e) => {
    e.preventDefault();
    if (!formState.name || !formState.amount || !formState.category || !formState.date) {
      toast.error("Please fill all fields.");
      return;
    }
    
    setIsSubmitting(true);
    const data = { ...formState, trip_id: tripId, amount: parseFloat(formState.amount) };
    
    try {
      await Expense.create(data);
      toast.success("Expense added!");
      const updatedExpenses = await Expense.filter({ trip_id: tripId }, '-date');
      setExpenses(updatedExpenses);
      setFormState({ name: '', amount: '', category: 'Food', date: new Date().toISOString().split('T')[0] });
    } catch (error) {
      console.error("Failed to add expense:", error);
      toast.error("Could not add expense.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteClick = useCallback((expense) => {
    setExpenseToDelete(expense);
    setShowDeleteConfirm(true);
  }, []);

  const confirmDelete = async () => {
    if (!expenseToDelete) return;
    try {
      await Expense.delete(expenseToDelete.id);
      setExpenses(prev => prev.filter(exp => exp.id !== expenseToDelete.id));
      toast.success("Expense deleted.");
    } catch (error) {
      console.error("Failed to delete expense:", error);
      toast.error("Could not delete expense.");
    } finally {
      setExpenseToDelete(null);
      setShowDeleteConfirm(false);
    }
  };
  
  const handleAnalyzeExpenses = async () => {
    setIsAnalyzing(true);
    setAnalysisResult(null);
    toast.info("AI is analyzing your expenses...");
    try {
      const response = await analyzeExpenses({ tripId });
      setAnalysisResult(response.data);
      toast.success("Analysis complete!");
    } catch (error) {
      console.error("AI analysis failed:", error);
      toast.error("AI analysis failed.", { description: error.message });
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  const budget = trip?.total_budget_amount || 0;
  const currency = trip?.budget_currency || 'USD';
  const progress = budget > 0 ? (totalSpent / budget) * 100 : 0;
  const isOverBudget = progress > 100;
  
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency }).format(amount);
  };

  const handleReturnToTripSelection = () => {
    // Navigate to the same page but without the tripId query parameter
    navigate(createPageUrl('ExpensesTracker'));
  };
  
  const renderTripSelection = () => (
    <div className="max-w-2xl mx-auto py-6 px-4">
      <div className="flex items-center gap-4 mb-8">
        <Button 
          variant="outline" 
          size="icon" 
          className="border-gray-300 text-slate-700 hover:bg-slate-200" 
          onClick={() => navigate(-1)}
        >
            <ArrowLeft className="w-4 h-4" />
        </Button>
        <h2 className="text-3xl font-bold text-dark-text">Select a Trip</h2>
      </div>

      <div className="text-center">
        <Landmark className="w-12 h-12 text-vivid-purple mx-auto mb-4" />
        <p className="text-medium-text mb-8">
          To track your spending, please choose one of your planned trips.
        </p>
      </div>
      
      {isLoading ? (
        <Loader2 className="w-8 h-8 animate-spin text-dark-text mx-auto" />
      ) : error ? (
         <div className="text-center text-red-500 bg-red-100 p-4 rounded-lg">
          <AlertCircle className="w-8 h-8 mx-auto mb-2" />
          <p>{error}</p>
        </div>
      ) : trips.length > 0 ? (
        <div className="space-y-3">
          {trips.map(t => (
            <button
              key={t.id}
              onClick={() => setSearchParams({ tripId: t.id })}
              className="w-full text-left p-4 bg-white border border-slate-200 rounded-lg flex items-center justify-between hover:bg-slate-50 hover:border-slate-300 transition-all shadow-sm"
            >
              <div>
                <p className="font-bold text-dark-text">{t.name}</p>
                <p className="text-sm text-medium-text">{t.destination} ({new Date(t.start_date).toLocaleDateString()} - {new Date(t.end_date).toLocaleDateString()})</p>
              </div>
              <ChevronRight className="w-5 h-5 text-slate-400" />
            </button>
          ))}
        </div>
      ) : (
        <div className="text-center bg-slate-100 p-8 rounded-lg">
          <FileQuestion className="w-12 h-12 text-slate-500 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-dark-text mb-2">No Trips Found</h3>
          <p className="text-medium-text mb-6">You don't have any trips yet. Create one to start tracking expenses.</p>
          <Button asChild className="bg-gradient-aurora text-white">
            <Link to={createPageUrl('CreateTrip')}>Create a New Trip</Link>
          </Button>
        </div>
      )}
    </div>
  );

  if (!tripId) {
    return (
      <div className="p-4 md:p-6 bg-slate-50 min-h-full">
        {renderTripSelection()}
      </div>
    );
  }

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center"><Loader2 className="w-8 h-8 animate-spin" /></div>;
  }

  if (error && !trip) {
    return (
      <div className="p-6 bg-slate-50 min-h-screen">
        <div className="max-w-4xl mx-auto text-center py-12">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-slate-800 mb-4">Error Loading Trip</h2>
          <p className="text-slate-600 mb-8">{error}</p>
          <Button onClick={() => setSearchParams({})} className="bg-gradient-aurora text-white">
            <ArrowLeft className="w-4 h-4 mr-2" /> Select Another Trip
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 bg-slate-50 min-h-full pb-28">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={handleReturnToTripSelection}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Select Another Trip</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <div>
            <h1 className="text-3xl font-bold text-slate-800">Expense Tracker</h1>
            <p className="text-slate-600">For your trip: {trip?.name}</p>
          </div>
        </div>

        {/* Budget Overview */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Budget Overview</CardTitle>
          </CardHeader>
          <CardContent>
            {budget > 0 ? (
              <>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-2xl font-bold text-slate-800">{formatCurrency(totalSpent)}</span>
                  <span className="text-slate-500">of {formatCurrency(budget)}</span>
                </div>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Progress value={progress} className={cn("w-full", isOverBudget ? "bg-red-200 [&>*]:bg-red-500" : "")} />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{progress.toFixed(1)}% of budget spent</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                <p className={cn("text-sm mt-2", isOverBudget ? "text-red-600 font-semibold" : "text-slate-600")}>
                  {isOverBudget ? (
                    <>
                      <AlertCircle className="inline-block w-4 h-4 mr-1 mb-0.5" />
                      You're over budget by {formatCurrency(totalSpent - budget)}!
                    </>
                  ) : (
                    `You've spent ${progress.toFixed(1)}% of your budget.`
                  )}
                </p>
              </>
            ) : (
              <p className="text-slate-600">No budget set for this trip. <Link to={createPageUrl('CreateTrip', {id: trip?.id})} className="text-blue-600 hover:underline">Add one now</Link>.</p>
            )}
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            {/* Add New Expense Form */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Add New Expense</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddExpense} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Expense Name</Label>
                      <Input id="name" name="name" value={formState.name} onChange={handleInputChange} placeholder="e.g., Dinner" />
                    </div>
                    <div>
                      <Label htmlFor="amount">Amount ({currency})</Label>
                      <Input id="amount" name="amount" type="number" value={formState.amount} onChange={handleInputChange} placeholder="e.g., 50.00" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select value={formState.category} onValueChange={handleSelectChange}>
                        <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                        <SelectContent>
                          {categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="date">Date</Label>
                      <Input id="date" name="date" type="date" value={formState.date} onChange={handleInputChange} />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button type="submit" disabled={isSubmitting}>
                      {isSubmitting ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Plus className="w-4 h-4 mr-2" />
                      )}
                      Add Expense
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            {/* AI Analysis */}
            <Card className="mb-6">
              <CardHeader className="flex flex-row items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="flex items-center gap-2">
                    <BrainCircuit className="w-6 h-6 text-primary" /> AI Expense Analysis
                  </CardTitle>
                  <CardDescription>Get smart insights on your spending.</CardDescription>
                </div>
                <Button onClick={handleAnalyzeExpenses} disabled={isAnalyzing || expenses.length === 0}>
                  {isAnalyzing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <TrendingUp className="mr-2 h-4 w-4" />}
                  Analyze
                </Button>
              </CardHeader>
              {analysisResult && (
                <CardContent>
                  <p className="text-slate-700 mb-4">{analysisResult.summary}</p>
                  <h4 className="font-semibold mb-2 text-slate-800">Money-Saving Tips:</h4>
                  <ul className="space-y-2">
                    {analysisResult.tips.map((tip, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Lightbulb className="w-5 h-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span className="text-slate-600">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              )}
            </Card>

            {/* Expense List */}
            <Card>
              <CardHeader><CardTitle>Your Expenses</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {expenses.map(exp => (
                    <div key={exp.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-100">
                      <div className="flex items-center gap-3">
                        <span className="text-slate-500">{categoryIcons[exp.category]}</span>
                        <div>
                          <p className="font-medium text-slate-800">{exp.name}</p>
                          <p className="text-sm text-slate-500">{exp.date}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-slate-800">{formatCurrency(exp.amount)}</span>
                        <Button variant="ghost" size="icon" onClick={() => handleDeleteClick(exp)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                      </div>
                    </div>
                  ))}
                  {expenses.length === 0 && <p className="text-center text-slate-500 py-8">No expenses logged yet.</p>}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Category Totals */}
          <div className="md:col-span-1">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="w-6 h-6 text-primary" /> Spending by Category
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {expensesByCategory.length > 0 ? (
                  <>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={expensesByCategory} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <XAxis type="number" hide />
                        <YAxis type="category" dataKey="name" width={80} tickFormatter={(value) => `${value}`} />
                        <RechartsTooltip formatter={(value) => formatCurrency(value)} cursor={{ fill: 'transparent' }} />
                        <Bar dataKey="value" barSize={20} radius={[0, 4, 4, 0]}>
                          {expensesByCategory.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={categoryColors[entry.name] || '#ccc'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                    <div className="space-y-2">
                      {expensesByCategory.map(cat => (
                        <div key={cat.name} className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="text-slate-600">{categoryIcons[cat.name]}</span>
                            <span className="font-medium text-slate-700">{cat.name}</span>
                          </div>
                          <span className="font-semibold text-slate-800">{formatCurrency(cat.value)}</span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="text-center text-slate-500 py-4">No expenses to categorize yet.</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Expense</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this expense? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}