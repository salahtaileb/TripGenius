
import React, { useState, useEffect, useRef } from 'react';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, UserCircle, Edit, Save, Award, BadgeCheck, ArrowLeft } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';
import { UploadFile } from '@/api/integrations';
import { cn } from '@/lib/utils';

export default function ProfilePage() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error('Failed to fetch user:', error);
        toast.error('Could not load your profile.');
      }
      setIsLoading(false);
    };
    fetchUser();
  }, []);

  const handleAvatarClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    toast.info('Uploading your new profile picture...');

    try {
      const { file_url } = await UploadFile({ file });
      await User.updateMyUserData({ profile_picture_url: file_url });
      setUser(prev => ({ ...prev, profile_picture_url: file_url }));
      toast.success('Profile picture updated successfully!');
    } catch (error) {
      console.error('Failed to upload profile picture:', error);
      toast.error('Failed to update profile picture.');
    } finally {
      setIsUploading(false);
    }
  };

  const handleUpdateProfile = async (event) => {
    event.preventDefault();
    const { fullName, citizenship } = event.target.elements;
    
    const updates = { 
      full_name: fullName.value,
      citizenship: citizenship.value || null
    };
    
    toast.info('Updating profile...');
    try {
      await User.updateMyUserData(updates);
      setUser(prev => ({ ...prev, ...updates }));
      toast.success('Profile updated!');
    } catch (error) {
      console.error('Failed to update profile:', error);
      toast.error('Failed to update profile information.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-soft-white">
        <Loader2 className="h-8 w-8 animate-spin text-electric-blue" />
      </div>
    );
  }

  if (!user) {
    return <div className="p-6 text-center text-medium-grey">Could not load user profile.</div>;
  }

  return (
    <div className="p-6 bg-gradient-to-b from-slate-50 to-slate-100 min-h-full pb-28">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate(-1)}
          className={cn(
            "group relative w-12 h-12 rounded-2xl border-2 backdrop-blur-sm flex items-center justify-center transition-all duration-300 transform hover:scale-105",
            "bg-gradient-to-br from-vivid-purple via-neon-pink to-electric-blue border-white/40 shadow-lg"
          )}
          style={{
            boxShadow: '0 8px 25px rgba(0,0,0,0.15), 0 0 20px rgba(157, 0, 255, 0.4)'
          }}
        >
          <ArrowLeft className="w-5 h-5 text-white drop-shadow-lg group-hover:scale-110 transition-transform" />
          <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
        </Button>
        <h1 className="text-3xl font-bold text-slate-800">My Profile</h1>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card className="bg-glass border border-electric-blue/20">
            <CardHeader className="items-center">
              <div className="relative">
                <Avatar className="w-32 h-32 border-4 border-white shadow-lg glow-electric">
                  <AvatarImage src={user.profile_picture_url} alt={user.full_name} />
                  <AvatarFallback className="bg-gradient-aurora">
                    <UserCircle className="w-16 h-16 text-white/80" />
                  </AvatarFallback>
                </Avatar>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  accept="image/*"
                />
                <Button
                  size="icon"
                  className="absolute bottom-1 right-1 rounded-full w-10 h-10 bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform duration-300"
                  onClick={handleAvatarClick}
                  disabled={isUploading}
                >
                  {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Edit className="w-5 h-5" />}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="text-center">
              <h2 className="text-2xl font-bold text-dark-readable">{user.full_name}</h2>
              <p className="text-medium-grey">{user.email}</p>
              <div className="mt-4 flex gap-2 justify-center">
                <div className="flex items-center gap-2 bg-electric-blue/10 text-electric-blue font-medium px-3 py-1 rounded-full border border-electric-blue/30">
                  <Award className="w-4 h-4" />
                  <span className="text-xs">{user.plan || 'Free'} Plan</span>
                </div>
                {user.is_affiliate && (
                  <div className="flex items-center gap-2 bg-neon-turquoise/10 text-neon-turquoise font-medium px-3 py-1 rounded-full border border-neon-turquoise/30">
                    <BadgeCheck className="w-4 h-4" />
                    <span className="text-xs">Affiliate</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        <div className="md:col-span-2">
          <Card className="bg-glass border border-vivid-purple/20">
            <CardHeader>
              <CardTitle className="text-dark-readable">Profile Information</CardTitle>
              <CardDescription className="text-medium-grey">Update your personal details here.</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-4" onSubmit={handleUpdateProfile}>
                <div>
                  <Label htmlFor="fullName" className="text-dark-readable">Full Name</Label>
                  <Input 
                    id="fullName" 
                    defaultValue={user.full_name} 
                    className="bg-white border-gray-200 text-dark-readable profile-input"
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-dark-readable">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email" 
                    value={user.email} 
                    disabled 
                    className="bg-gray-50 border-gray-200 text-medium-grey profile-input"
                  />
                  <p className="text-xs text-medium-grey mt-1">Email address cannot be changed.</p>
                </div>
                <div>
                  <Label htmlFor="citizenship" className="text-dark-readable">Citizenship (for travel documents)</Label>
                  <Input 
                    id="citizenship" 
                    placeholder="e.g. US, GB, DE, FR" 
                    defaultValue={user.citizenship || ''} 
                    className="bg-white border-gray-200 text-dark-readable profile-input"
                  />
                  <p className="text-xs text-medium-grey mt-1">Enter your country code for travel requirements checks.</p>
                </div>
                <div className="flex justify-end">
                  <Button type="submit" className="bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform duration-300">
                    <Save className="w-4 h-4 mr-2"/>
                    Save Changes
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <style jsx>{`
        .profile-input:-webkit-autofill,
        .profile-input:-webkit-autofill:hover,
        .profile-input:-webkit-autofill:focus,
        .profile-input:-webkit-autofill:active {
          -webkit-box-shadow: 0 0 0px 1000px #ffffff inset !important;
          -webkit-text-fill-color: #1E1E1E !important;
          box-shadow: 0 0 0px 1000px #ffffff inset !important;
          background-color: #ffffff !important;
        }
      `}</style>
    </div>
  );
}
