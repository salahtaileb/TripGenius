
import React, { useState, useEffect, useCallback } from 'react';
import { Notification } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, AlertCircle, BellRing, ArrowLeft, Sparkles, Tag, Plane, CheckCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

const iconMap = {
  trip: <Plane className="w-5 h-5" />,
  deal: <Tag className="w-5 h-5" />,
  chat: <Sparkles className="w-5 h-5" />,
  system: <BellRing className="w-5 h-5" />,
  welcome: <Sparkles className="w-5 h-5" />,
};

const iconColorMap = {
  trip: 'bg-blue-100 text-blue-600',
  deal: 'bg-orange-100 text-orange-600',
  chat: 'bg-purple-100 text-purple-600',
  system: 'bg-slate-100 text-slate-600',
  welcome: 'bg-green-100 text-green-600',
};

const NotificationItem = ({ notification, onMarkAsRead }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    if (!notification.is_read) {
      onMarkAsRead(notification.id);
    }
    if (notification.link) {
      navigate(notification.link);
    }
  };

  return (
    <Card
      onClick={handleClick}
      className={cn(
        'transition-all duration-300 cursor-pointer group',
        notification.is_read
          ? 'bg-slate-50/80 border-slate-200/50'
          : 'bg-white/80 border-slate-200/80 hover:bg-white hover:shadow-lg hover:border-slate-300'
      )}
    >
      <CardContent className="p-4 flex items-start gap-4">
        {!notification.is_read && (
          <div className="w-2 h-2 rounded-full bg-electric-blue mt-2.5 flex-shrink-0 animate-pulse" />
        )}
        <div className={cn(
          "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
          iconColorMap[notification.icon] || iconColorMap.system
        )}>
          {iconMap[notification.icon] || iconMap.system}
        </div>
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <h4 className="font-bold text-slate-800 pr-4">{notification.title}</h4>
            <p className="text-xs text-slate-500 flex-shrink-0">
              {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
            </p>
          </div>
          <p className="text-sm text-slate-600 mt-1">{notification.message}</p>
        </div>
      </CardContent>
    </Card>
  );
};


export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const loadNotifications = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      const data = await Notification.list('-created_date');
      setNotifications(data || []);
    } catch (e) {
      setError('Could not load notifications. Please log in.');
      toast.error('You need to be logged in to see your notifications.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadNotifications();
  }, [loadNotifications]);

  const handleMarkAsRead = async (id) => {
    const notification = notifications.find(n => n.id === id);
    if (notification && !notification.is_read) {
      try {
        await Notification.update(id, { is_read: true });
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
      } catch (err) {
        console.error("Failed to mark as read:", err);
      }
    }
  };

  const handleMarkAllAsRead = async () => {
    toast.info("Marking all as read...");
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);
    if (unreadIds.length === 0) {
        toast.success("No unread notifications.");
        return;
    }
    
    try {
      await Promise.all(unreadIds.map(id => Notification.update(id, { is_read: true })));
      loadNotifications(); // Refresh from server
      toast.success("All notifications marked as read.");
    } catch (err) {
        console.error("Failed to mark all as read:", err);
        toast.error("Could not mark all as read.");
    }
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-electric-blue" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-50 p-6 text-center">
        <div>
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-800 mb-2">An Error Occurred</h2>
          <p className="text-slate-600 mb-6">{error}</p>
          <Button onClick={() => navigate(createPageUrl('Home'))}>Go to Homepage</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-full bg-gradient-to-b from-slate-50 to-white p-6 pb-28">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" className="border-slate-300/80 text-slate-700 hover:bg-slate-100" onClick={() => navigate(-1)}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-slate-800">Notifications</h1>
              <p className="text-slate-500">You have {unreadCount} unread notifications.</p>
            </div>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={handleMarkAllAsRead}>
              <CheckCheck className="w-4 h-4 mr-2" />
              Mark all as read
            </Button>
          )}
        </div>

        {notifications.length > 0 ? (
          <div className="space-y-4">
            {notifications.map(notification => (
              <NotificationItem
                key={notification.id}
                notification={notification}
                onMarkAsRead={handleMarkAsRead}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-slate-100/80 rounded-2xl border border-slate-200/80">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 border border-slate-200 shadow-sm">
              <BellRing className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-2xl font-bold text-slate-800 mb-2">All Caught Up!</h3>
            <p className="text-slate-600 max-w-sm mx-auto">
              You don't have any notifications right now. We'll let you know when something new comes up.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
