
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Trip } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CalendarDays, MapPin, Users, Save, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function CreateTripPage() {
  const [formData, setFormData] = useState({
    name: '',
    destination: '',
    latitude: '',
    longitude: '',
    start_date: '',
    end_date: '',
    travelers: 1,
    budget: 'mid-range',
    status: 'planning',
    total_budget_amount: '',
    budget_currency: 'USD'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { id } = useParams(); // Destructure id from useParams

  // Effect to fetch trip data for editing if an ID is present
  useEffect(() => {
    const fetchTripData = async () => {
      if (id) {
        try {
          const tripData = await Trip.get(id);
          setFormData({
            name: tripData.name || '',
            destination: tripData.destination || '',
            latitude: tripData.latitude !== undefined && tripData.latitude !== null ? String(tripData.latitude) : '',
            longitude: tripData.longitude !== undefined && tripData.longitude !== null ? String(tripData.longitude) : '',
            start_date: tripData.start_date || '',
            end_date: tripData.end_date || '',
            travelers: tripData.travelers || 1,
            budget: tripData.budget || 'mid-range',
            status: tripData.status || 'planning',
            total_budget_amount: tripData.total_budget_amount !== undefined && tripData.total_budget_amount !== null ? String(tripData.total_budget_amount) : '',
            budget_currency: tripData.budget_currency || 'USD'
          });
        } catch (error) {
          console.error("Failed to fetch trip data:", error);
          toast.error("Could not load trip data for editing.");
          navigate(createPageUrl('MyTrips'));
        }
      }
    };
    fetchTripData();
  }, [id, navigate]); // Rerun when id or navigate changes

  // Extract URL parameters for pre-filling (runs when component mounts or search params change, but not if 'id' is set and already fetched data)
  useEffect(() => {
    // Only pre-fill from URL if not in edit mode (no ID) and destination isn't already set by a previous fetch
    if (!id && !formData.destination) {
      const urlParams = new URLSearchParams(window.location.search);
      const destination = urlParams.get('destination');
      const latitude = urlParams.get('latitude');
      const longitude = urlParams.get('longitude');

      if (destination) {
        setFormData(prev => ({
          ...prev,
          destination,
          latitude: latitude || '',
          longitude: longitude || ''
        }));
      }
    }
  }, [id, formData.destination]); // Depend on id and formData.destination to prevent re-applying after edit fetch

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.destination) {
      toast.error('Please fill in trip name and destination');
      return;
    }

    setIsSubmitting(true);
    try {
      const tripData = {
        ...formData,
        travelers: parseInt(formData.travelers, 10),
        latitude: formData.latitude ? parseFloat(formData.latitude) : null,
        longitude: formData.longitude ? parseFloat(formData.longitude) : null,
        total_budget_amount: formData.total_budget_amount ? parseFloat(formData.total_budget_amount) : null,
      };

      if (id) {
        await Trip.update(id, tripData);
        toast.success('Trip updated successfully!');
      } else {
        await Trip.create(tripData);
        toast.success('Trip created successfully!');
      }
      navigate(createPageUrl('MyTrips'));
    } catch (error) {
      console.error('Error creating/updating trip:', error);
      toast.error('Failed to save trip. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen p-6 bg-gradient-to-b from-slate-50 to-slate-100 pb-28">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" className="border-gray-300 text-slate-700 hover:bg-slate-200" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">{id ? 'Edit Trip' : 'Create New Trip'}</h1>
            <p className="text-slate-600">{id ? 'Update your trip details' : 'Plan your next adventure manually'}</p>
          </div>
        </div>

        <Card className="bg-white/90 backdrop-blur-sm border border-gray-200/50 shadow-lg">
          <CardHeader>
            <CardTitle className="text-slate-800">{id ? 'Trip Details' : 'Trip Details'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name" className="text-slate-700">Trip Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleChange('name', e.target.value)}
                    placeholder="e.g., Summer in Japan"
                    required
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <Label htmlFor="destination" className="text-slate-700">Destination *</Label>
                  <Input
                    id="destination"
                    value={formData.destination}
                    onChange={(e) => handleChange('destination', e.target.value)}
                    placeholder="e.g., Tokyo, Japan"
                    required
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="latitude" className="text-slate-700">Latitude (Optional)</Label>
                  <Input
                    id="latitude"
                    type="number"
                    step="any"
                    value={formData.latitude}
                    onChange={(e) => handleChange('latitude', e.target.value)}
                    placeholder="35.6762"
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <Label htmlFor="longitude" className="text-slate-700">Longitude (Optional)</Label>
                  <Input
                    id="longitude"
                    type="number"
                    step="any"
                    value={formData.longitude}
                    onChange={(e) => handleChange('longitude', e.target.value)}
                    placeholder="139.6503"
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="start_date" className="text-slate-700">Start Date</Label>
                  <Input
                    id="start_date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => handleChange('start_date', e.target.value)}
                    className="bg-white border-gray-300 text-slate-800"
                  />
                </div>
                <div>
                  <Label htmlFor="end_date" className="text-slate-700">End Date</Label>
                  <Input
                    id="end_date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => handleChange('end_date', e.target.value)}
                    className="bg-white border-gray-300 text-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="total_budget_amount" className="text-slate-700">Total Budget</Label>
                  <Input
                    id="total_budget_amount"
                    type="number"
                    step="any"
                    value={formData.total_budget_amount}
                    onChange={(e) => handleChange('total_budget_amount', e.target.value)}
                    placeholder="e.g., 2000"
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
                <div>
                  <Label htmlFor="budget_currency" className="text-slate-700">Budget Currency</Label>
                  <Input
                    id="budget_currency"
                    value={formData.budget_currency}
                    onChange={(e) => handleChange('budget_currency', e.target.value.toUpperCase())}
                    placeholder="e.g., USD"
                    maxLength="3"
                    className="bg-white border-gray-300 text-slate-800 placeholder:text-slate-400"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <Label htmlFor="travelers" className="text-slate-700">Travelers</Label>
                  <Input
                    id="travelers"
                    type="number"
                    min="1"
                    value={formData.travelers}
                    onChange={(e) => handleChange('travelers', e.target.value)}
                    className="bg-white border-gray-300 text-slate-800"
                  />
                </div>
                <div>
                  <Label className="text-slate-700">Budget</Label>
                  <Select value={formData.budget} onValueChange={(value) => handleChange('budget', value)}>
                    <SelectTrigger className="bg-white border-gray-300 text-slate-800">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="budget">Budget</SelectItem>
                      <SelectItem value="mid-range">Mid-range</SelectItem>
                      <SelectItem value="luxury">Luxury</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-slate-700">Status</Label>
                  <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                    <SelectTrigger className="bg-white border-gray-300 text-slate-800">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="planning">Planning</SelectItem>
                      <SelectItem value="booked">Booked</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end gap-4 pt-6">
                <Button 
                  type="button"
                  variant="outline" 
                  className="border-gray-300 text-slate-700 hover:bg-slate-200"
                  onClick={() => navigate(-1)}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform duration-300"
                  disabled={isSubmitting}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isSubmitting ? (id ? 'Updating...' : 'Creating...') : (id ? 'Update Trip' : 'Create Trip')}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
