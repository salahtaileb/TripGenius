
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  MessageSquare, 
  CalendarDays,
  Users2, 
  Sparkles, 
  ArrowRight,
  Globe,
  Camera,
  Zap,
  FileText,
  Tag,
  Star,
  MapPin,
  Heart
} from 'lucide-react';
import { cn } from '@/lib/utils';

const features = [
  {
    icon: MessageSquare,
    title: 'AI Travel Concierge',
    description: 'Chat with our AI to plan perfect trips tailored to your style and budget.',
    page: 'Chat',
    gradient: 'from-sky-400 via-blue-500 to-indigo-600',
    glowColor: 'sky-500',
    accentIcon: Sparkles
  },
  {
    icon: FileText,
    title: 'Smart Itineraries',
    description: 'Get inspired by detailed guides and tips from seasoned travelers.',
    page: 'Blogs',
    gradient: 'from-emerald-400 via-teal-500 to-cyan-600',
    glowColor: 'emerald-500',
    accentIcon: Star
  },
  {
    icon: Users2,
    title: 'Traveler Stories',
    description: 'Read real stories and get authentic advice from our community of adventurers.',
    page: 'Blogs',
    gradient: 'from-rose-400 via-pink-500 to-purple-600',
    glowColor: 'rose-500',
    accentIcon: Heart
  },
  {
    icon: Tag,
    title: 'Exclusive Deals',
    description: 'Discover handpicked deals on flights and hotels to save money on your next journey.',
    page: 'Deals',
    gradient: 'from-orange-400 via-amber-500 to-yellow-500',
    glowColor: 'orange-500',
    accentIcon: Zap
  }
];

const destinations = [
  {
    name: 'Paris, France',
    image: 'https://images.unsplash.com/photo-1502602898536-47ad22581b52?auto=format&fit=crop&w=500&q=80',
    description: 'City of Light',
    color: 'from-blue-400 to-purple-600'
  },
  {
    name: 'Tokyo, Japan',
    image: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=500&q=80',
    description: 'Neon Dreams',
    color: 'from-pink-400 to-red-600'
  },
  {
    name: 'Santorini, Greece',
    image: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=500&q=80',
    description: 'Island Paradise',
    color: 'from-cyan-400 to-blue-600'
  },
  {
    name: 'Dubai, UAE',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=500&q=80',
    description: 'Future City',
    color: 'from-amber-400 to-orange-600'
  }
];

export default function HomePage() {
  return (
    <div className="min-h-screen text-slate-900 bg-gradient-to-br from-slate-50 to-white overflow-y-auto relative pb-28">
      {/* Subtle background patterns */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--electric-blue)_0%,_transparent_50%)] opacity-5 pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--vivid-purple)_0%,_transparent_50%)] opacity-5 pointer-events-none" />
      
      {/* Hero Section - Enhanced with Better Typography and Spacing */}
      <section className="relative overflow-hidden min-h-screen flex items-center">
        <div className="relative max-w-7xl mx-auto px-6 py-20 text-center z-10">
          {/* Enhanced Aurora Badge */}
          <div className="inline-flex items-center gap-3 bg-white/60 backdrop-blur-md px-8 py-4 rounded-full text-sm font-medium mb-12 border border-white/40 shadow-lg hover:shadow-xl transition-all duration-500 group cursor-default"
               style={{
                 boxShadow: '0 8px 32px rgba(14, 165, 233, 0.15)'
               }}>
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-sky-400 via-violet-500 to-pink-500 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
              <Sparkles className="w-4 h-4 text-white drop-shadow-sm" />
            </div>
            <span className="bg-gradient-to-r from-sky-600 via-violet-600 to-pink-600 bg-clip-text text-transparent font-bold tracking-wide">
              AI-Powered Travel Planning
            </span>
            <div className="w-2 h-2 rounded-full bg-gradient-to-r from-sky-400 to-violet-500 animate-pulse" />
          </div>
          
          {/* Enhanced Hero Title with Better Animation */}
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.9] mb-8 tracking-tight">
            <span className="text-slate-900 block">Your Next</span>
            <span className="bg-gradient-to-r from-sky-500 via-violet-600 to-pink-500 bg-clip-text text-transparent block py-2 animate-aurora">
              Adventure
            </span>
            <span className="text-slate-900 block">Starts Here</span>
          </h1>
          
          {/* Enhanced Description */}
          <p className="text-lg md:text-xl lg:text-2xl text-slate-600 mb-16 max-w-4xl mx-auto leading-relaxed font-medium">
            Let our AI travel concierge craft the perfect itinerary. From hidden gems to must-see attractions, 
            <span className="text-slate-800 font-semibold"> we've got every detail covered</span>.
          </p>
          
          {/* Enhanced CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 justify-center mb-20">
            <Link to={createPageUrl('Chat')}>
              <Button 
                size="lg" 
                className={cn(
                  "group relative h-16 px-12 text-lg overflow-hidden rounded-2xl border-0 shadow-2xl transition-all duration-500 transform hover:scale-105 active:scale-95",
                  "bg-gradient-to-r from-sky-500 via-violet-600 to-pink-500 text-white font-bold",
                  "hover:shadow-[0_20px_50px_rgba(14,165,233,0.4)]"
                )}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-sky-600 via-violet-700 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <MessageSquare className="w-6 h-6 mr-3 relative z-10 group-hover:rotate-12 transition-transform duration-300" />
                <span className="relative z-10">Start Planning Now</span>
                <ArrowRight className="w-6 h-6 ml-3 relative z-10 group-hover:translate-x-1 transition-transform duration-300" />
                
                {/* Shimmer effect */}
                <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-1000 ease-out" />
              </Button>
            </Link>
            
            <Link to={createPageUrl('MyTrips')}>
              <Button 
                variant="outline" 
                size="lg" 
                className={cn(
                  "group relative h-16 px-12 text-lg border-2 rounded-2xl transition-all duration-500 transform hover:scale-105 active:scale-95 overflow-hidden",
                  "bg-white/60 backdrop-blur-md border-slate-200 hover:border-violet-300 hover:bg-white/80",
                  "shadow-lg hover:shadow-xl"
                )}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-sky-50 via-violet-50 to-pink-50 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <CalendarDays className="w-6 h-6 mr-3 text-violet-600 relative z-10 group-hover:scale-110 transition-transform duration-300" />
                <span className="bg-gradient-to-r from-sky-600 via-violet-600 to-pink-600 bg-clip-text text-transparent font-bold relative z-10">
                  View My Trips
                </span>
              </Button>
            </Link>
          </div>

          {/* Trust indicators */}
          <div className="flex items-center justify-center gap-8 text-slate-500 text-sm">
            <div className="flex items-center gap-2">
              <div className="flex -space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="font-medium">Trusted by 10k+ travelers</span>
            </div>
            <div className="hidden md:block w-1 h-1 bg-slate-300 rounded-full" />
            <div className="hidden md:flex items-center gap-2">
              <Globe className="w-4 h-4" />
              <span className="font-medium">200+ destinations</span>
            </div>
          </div>
        </div>

        {/* Floating elements for visual interest */}
        <div className="absolute top-1/4 left-10 w-2 h-2 bg-sky-400 rounded-full animate-ping opacity-60" />
        <div className="absolute top-1/3 right-20 w-3 h-3 bg-violet-400 rounded-full animate-pulse opacity-40" />
        <div className="absolute bottom-1/4 left-1/4 w-2 h-2 bg-pink-400 rounded-full animate-bounce opacity-50" />
      </section>

      {/* Enhanced Features Section */}
      <section className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 tracking-tight">
              Everything You Need
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              From AI-powered planning to real traveler insights, we've built the complete travel companion.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Link key={feature.title} to={createPageUrl(feature.page)}>
                <Card className={cn(
                  "group h-full transition-all duration-500 transform hover:scale-105 hover:-translate-y-2",
                  "bg-white/70 backdrop-blur-md border border-white/40 hover:border-white/60",
                  "hover:shadow-2xl rounded-3xl overflow-hidden",
                  "cursor-pointer active:scale-95"
                )}>
                  <CardContent className="p-8 text-center relative">
                    {/* Enhanced background glow */}
                    <div className={cn(
                      "absolute inset-0 opacity-0 group-hover:opacity-20 transition-all duration-700 rounded-3xl",
                      `bg-gradient-to-br ${feature.gradient}`
                    )} />
                    
                    {/* Enhanced Icon Container */}
                    <div className={cn(
                      "relative w-24 h-24 rounded-3xl border-2 backdrop-blur-md flex items-center justify-center mx-auto mb-6",
                      "transition-all duration-500 transform group-hover:scale-110 group-hover:rotate-3",
                      `bg-gradient-to-br ${feature.gradient} border-white/30 shadow-xl`,
                      "hover:shadow-2xl"
                    )}
                    style={{
                      boxShadow: `0 12px 40px rgba(0,0,0,0.15)`
                    }}
                    >
                      {/* Accent icon in corner */}
                      <feature.accentIcon className="absolute -top-2 -right-2 w-5 h-5 text-white bg-slate-900 rounded-full p-1 opacity-0 group-hover:opacity-100 transition-all duration-300" />
                      
                      {/* Main icon */}
                      <feature.icon className="w-12 h-12 relative z-10 text-white drop-shadow-lg transition-all duration-500 group-hover:scale-110" />
                      
                      {/* Enhanced shimmer */}
                      <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
                    </div>
                    
                    {/* Enhanced title */}
                    <h3 className={cn(
                      "text-xl font-bold mb-4 relative z-10 transition-all duration-300",
                      "text-slate-900 group-hover:text-slate-800"
                    )}>
                      {feature.title}
                    </h3>
                    
                    {/* Enhanced description */}
                    <p className="text-slate-600 group-hover:text-slate-700 transition-colors duration-300 relative z-10 leading-relaxed text-sm">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Popular Destinations */}
      <section className="py-32 px-6 bg-gradient-to-br from-slate-100/50 to-white/80 relative">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-24">
            <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 tracking-tight">
              Popular Destinations
            </h2>
            <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Discover trending destinations and get inspired for your next adventure.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {destinations.map((destination, index) => (
              <Card key={destination.name} className={cn(
                "group transition-all duration-500 transform hover:scale-105 hover:-translate-y-2",
                "bg-white/80 backdrop-blur-md border border-white/50 hover:border-white/70",
                "hover:shadow-2xl rounded-3xl overflow-hidden cursor-pointer"
              )}>
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={destination.image} 
                    alt={destination.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className={cn(
                    "absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent",
                    "group-hover:from-black/70 transition-all duration-500"
                  )}></div>
                  
                  {/* Floating badge */}
                  <div className="absolute top-4 right-4 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full border border-white/30">
                    <MapPin className="w-4 h-4 text-white inline" />
                  </div>
                  
                  <div className="absolute bottom-6 left-6 text-white">
                    <p className="text-sm opacity-90 mb-1 font-medium">{destination.description}</p>
                    <h3 className="text-xl font-bold group-hover:text-yellow-300 transition-colors duration-300">
                      {destination.name}
                    </h3>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section className="py-32 px-6 relative">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-12 tracking-tight">
            <span className="text-slate-900">Ready to Start Your </span>
            <span className="bg-gradient-to-r from-sky-500 via-violet-600 to-pink-500 bg-clip-text text-transparent animate-aurora">
              Journey?
            </span>
          </h2>
          <p className="text-xl text-slate-600 mb-16 max-w-2xl mx-auto leading-relaxed">
            Join thousands of travelers who trust TripGenius to plan their perfect adventures.
          </p>
          
          <Link to={createPageUrl('Chat')}>
            <Button 
              size="lg" 
              className={cn(
                "group relative h-20 px-16 text-xl overflow-hidden rounded-3xl border-0 shadow-2xl transition-all duration-500 transform hover:scale-105",
                "bg-gradient-to-r from-sky-500 via-violet-600 to-pink-500 text-white font-bold",
                "hover:shadow-[0_25px_60px_rgba(14,165,233,0.4)]"
              )}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-sky-600 via-violet-700 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <MessageSquare className="w-7 h-7 mr-4 relative z-10 group-hover:rotate-12 transition-transform duration-300" />
              <span className="relative z-10">Start Planning Free</span>
              <ArrowRight className="w-7 h-7 ml-4 relative z-10 group-hover:translate-x-2 transition-transform duration-300" />
              
              {/* Enhanced shimmer */}
              <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full bg-gradient-to-r from-transparent via-white/30 to-transparent transition-transform duration-1200 ease-out" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
