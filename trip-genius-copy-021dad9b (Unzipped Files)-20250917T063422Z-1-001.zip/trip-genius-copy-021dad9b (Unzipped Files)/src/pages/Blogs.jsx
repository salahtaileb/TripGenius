
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, FileText, PlusCircle, User, Loader2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { PhotoStory } from '@/api/entities';
import { User as UserEntity } from '@/api/entities';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const blogPosts = [
  {
    id: '1',
    title: 'Hidden Gems of Southeast Asia',
    excerpt: 'Discover secret beaches, hidden temples, and local favorites that most tourists never see.',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=800&q=80',
    category: 'Travel Guide',
    created_date: '2024-01-15',
  },
  {
    id: '2', 
    title: 'Budget Travel Tips for Europe',
    excerpt: 'How to explore 10 European countries on less than $50 per day.',
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=800&q=80',
    category: 'Budget Travel',
    created_date: '2024-01-10',
  },
];

const StoryCard = ({ story, currentUser, onDelete }) => {
  const isOwner = currentUser && story.created_by === currentUser.email;
  
  // FOR TESTING: Show delete button on ALL stories temporarily
  console.log('Story:', story.title, 'Owner?', isOwner, 'Current User:', currentUser?.email, 'Story Creator:', story.created_by);

  const handleDelete = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onDelete(story.id);
  };

  return (
    <div className="relative">
      {/* TEMPORARILY SHOW DELETE BUTTON ON ALL STORIES FOR TESTING */}
      <Button
        variant="destructive"
        size="icon"
        onClick={handleDelete}
        className="absolute top-2 right-2 z-50 w-12 h-12 rounded-full bg-red-600 hover:bg-red-700 text-white shadow-2xl border-4 border-white"
        style={{
          position: 'absolute',
          top: '8px',
          right: '8px',
          zIndex: 50
        }}
      >
        <Trash2 className="w-6 h-6" />
      </Button>
      
      <Link to={createPageUrl(`PhotoStoryView?id=${story.id}`)}>
        <Card className="overflow-hidden h-full bg-white border-2 border-transparent hover:border-black hover:shadow-lg transition-all duration-300 rounded-2xl">
          <div className="relative">
            <img 
              src={story.photo_urls && story.photo_urls.length > 0 ? story.photo_urls[0] : 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80'} 
              alt={story.title} 
              className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500" 
            />
            <div className="absolute top-4 left-4 bg-black/60 px-3 py-1 rounded-full text-xs font-semibold text-white border border-gray-500/30">User Story</div>
          </div>
          <CardContent className="p-6 flex flex-col bg-white">
            <div className="flex-1">
              <h3 className="text-xl font-bold text-dark-text mb-2">{story.title}</h3>
              <p className="text-medium-text text-sm mb-4 line-clamp-2">{story.description || 'A beautiful travel story shared by our community.'}</p>
            </div>
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={story.author_avatar_url} />
                  <AvatarFallback><User className="w-4 h-4" /></AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium text-medium-text">{story.author_name || 'Anonymous'}</span>
              </div>
              <div className="flex items-center text-dark-text font-semibold group-hover:gap-3 transition-all duration-300">
                Read Story
                <ArrowRight className="w-4 h-4 ml-2" />
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </div>
  );
};

const BlogCard = ({ post }) => (
  <Link to={createPageUrl(`BlogPost?id=${post.id}`)} key={post.id} className="group">
    <Card className="overflow-hidden h-full bg-white border-2 border-transparent hover:border-black hover:shadow-lg transition-all duration-300 rounded-2xl">
      <div className="relative">
        <img src={post.image} alt={post.title} className="w-full h-56 object-cover group-hover:scale-105 transition-transform duration-500" />
        <div className="absolute top-4 left-4 bg-black/60 px-3 py-1 rounded-full text-xs font-semibold text-white border border-gray-500/30">{post.category}</div>
      </div>
      <CardContent className="p-6 flex flex-col bg-white">
        <div className="flex-1">
          <h3 className="text-xl font-bold text-dark-text mb-2">{post.title}</h3>
          <p className="text-medium-text text-sm mb-4 line-clamp-2">{post.excerpt}</p>
        </div>
        <div className="flex items-center text-dark-text font-semibold group-hover:gap-3 transition-all duration-300">
          Read More
          <ArrowRight className="w-4 h-4 ml-2" />
        </div>
      </CardContent>
    </Card>
  </Link>
);

export default function BlogsPage() {
  const [stories, setStories] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [storyToDelete, setStoryToDelete] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      try {
        const [user, storyData] = await Promise.all([
          UserEntity.me().catch(() => null),
          PhotoStory.list('-created_date')
        ]);
        setCurrentUser(user);
        setStories(storyData || []);
        console.log('Current user:', user);
        console.log('Stories loaded:', storyData);
      } catch (error) {
        console.error("Error loading blog data:", error);
        toast.error("Could not load stories.");
      } finally {
        setIsLoading(false);
      }
    };
    loadData();
  }, []);

  const handleDeleteClick = (storyId) => {
    setStoryToDelete(storyId);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!storyToDelete) return;
    setIsDeleting(true);
    try {
      await PhotoStory.delete(storyToDelete);
      toast.success("Story deleted successfully.");
      setStories(prev => prev.filter(s => s.id !== storyToDelete));
    } catch (error) {
      toast.error("Failed to delete story.");
      console.error(error);
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setStoryToDelete(null);
    }
  };

  return (
    <>
      <div className="min-h-screen bg-soft-white p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-dark-text">Travel Blog & Stories</h1>
              <p className="text-medium-text">Get inspired by our guides and community stories.</p>
            </div>
            <Link to={createPageUrl('CreateStory')}>
              <Button className="bg-electric-blue text-white hover:bg-electric-blue/90">
                <PlusCircle className="w-4 h-4 mr-2" />
                Create Story
              </Button>
            </Link>
          </div>

          <div className="mb-12">
            <h2 className="text-2xl font-bold text-dark-text mb-6 flex items-center gap-2">
              <FileText className="w-6 h-6 text-electric-blue" />
              Featured Guides
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogPosts.map(post => <BlogCard key={post.id} post={post} />)}
            </div>
          </div>

          <div className="mb-12">
            <h2 className="text-2xl font-bold text-dark-text mb-6 flex items-center gap-2">
              <User className="w-6 h-6 text-electric-blue" />
              Community Stories
            </h2>
            {isLoading ? (
              <div className="text-center py-10">
                <Loader2 className="w-8 h-8 animate-spin text-medium-text mx-auto" />
                <p className="mt-2 text-medium-text">Loading stories...</p>
              </div>
            ) : stories.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {stories.map(story => (
                  <StoryCard 
                    key={story.id} 
                    story={story} 
                    currentUser={currentUser} 
                    onDelete={handleDeleteClick} 
                  />
                ))}
              </div>
            ) : (
              <p className="text-medium-text">No community stories shared yet. Be the first!</p>
            )}
          </div>
        </div>
      </div>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Story</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this story? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
              {isDeleting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Delete Story
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
