import React, { useState, useEffect } from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { PhotoStory } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, AlertTriangle, ArrowLeft, User, MapPin, Share2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { createPageUrl } from '@/utils';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';

export default function PhotoStoryViewPage() {
  const [story, setStory] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchStory = async () => {
      const params = new URLSearchParams(location.search);
      const storyId = params.get('id');
      if (!storyId) {
        setError("No photo story ID provided.");
        setIsLoading(false);
        return;
      }
      try {
        const [storyData] = await PhotoStory.filter({ id: storyId });
        if (storyData) {
          setStory(storyData);
        } else {
          setError("Photo story not found.");
        }
      } catch (e) {
        setError("Failed to fetch photo story.");
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    };
    fetchStory();
  }, [location.search]);

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-electric-blue" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col h-full w-full items-center justify-center bg-slate-50 p-6">
        <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
        <h2 className="text-xl font-bold text-slate-800">{error}</h2>
        <Button onClick={() => navigate(createPageUrl('Blogs'))} className="mt-4">Back to Blog</Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-6 bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
             <Button variant="outline" size="icon" className="border-gray-300 text-slate-700 hover:bg-slate-200" onClick={() => navigate(-1)}>
                <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-3xl font-bold text-slate-800">{story.title}</h1>
        </div>

        <Card className="bg-white/90 backdrop-blur-sm shadow-lg border-gray-200/50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={story.author_avatar_url} />
                      <AvatarFallback><User className="w-6 h-6" /></AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-slate-800">{story.author_name}</p>
                      {story.location && <p className="text-sm text-slate-500 flex items-center gap-1"><MapPin className="w-3 h-3"/>{story.location}</p>}
                    </div>
                </div>
                <Button variant="outline"><Share2 className="w-4 h-4 mr-2"/>Share</Button>
            </div>
            
            {story.photo_urls && story.photo_urls.length > 0 && (
              <Carousel className="w-full mb-6">
                <CarouselContent>
                  {story.photo_urls.map((url, index) => (
                    <CarouselItem key={index}>
                      <div className="p-1">
                          <img src={url} alt={`Photo ${index + 1} for ${story.title}`} className="w-full h-auto max-h-[70vh] object-contain rounded-lg bg-slate-100" />
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <CarouselPrevious className="ml-16" />
                <CarouselNext className="mr-16" />
              </Carousel>
            )}

            {story.description && (
                <div className="prose prose-lg max-w-none text-slate-700">
                    <p>{story.description}</p>
                </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}