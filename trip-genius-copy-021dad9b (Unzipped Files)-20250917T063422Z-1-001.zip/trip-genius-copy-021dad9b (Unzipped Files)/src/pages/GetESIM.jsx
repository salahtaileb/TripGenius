
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Signal, ExternalLink, Globe, Wifi, Smartphone, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { getAffiliateTokens } from '@/api/functions';

const benefits = [
  {
    icon: <Wifi className="w-6 h-6" />,
    title: 'Instant Connection',
    description: 'Connect as soon as you land - no waiting for physical SIM cards'
  },
  {
    icon: <Globe className="w-6 h-6" />,
    title: 'Global Coverage',
    description: 'Available in 200+ countries and regions worldwide'
  },
  {
    icon: <Smartphone className="w-6 h-6" />,
    title: 'Easy Setup',
    description: 'Simply scan QR code and you\'re connected in minutes'
  }
];

export default function GetESIMPage() {
  const navigate = useNavigate();
  const [tokens, setTokens] = useState({ airalo: '', holafly: '' });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadTokens = async () => {
      try {
        const response = await getAffiliateTokens();
        setTokens(response.data);
      } catch (error) {
        console.error('Error loading tokens:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadTokens();
  }, []);

  const handleProviderClick = (url) => {
    window.open(url, '_blank');
  };

  const handleBackClick = () => {
    navigate(-1);
  };

  const esimProviders = [
    {
      name: 'Airalo',
      description: 'World\'s first eSIM marketplace with 200+ destinations',
      logo: '✈️',
      features: ['Global coverage', 'Instant activation', 'Multiple plans', 'Top-rated app'],
      url: tokens.airalo ? `https://www.airalo.com/?ref=${tokens.airalo}` : 'https://www.airalo.com',
      color: 'bg-blue-600 text-white',
      badge: 'Most Popular'
    },
    {
      name: 'Holafly',
      description: 'Unlimited data plans for travelers worldwide',
      logo: '🌍',
      features: ['Unlimited data', '24/7 support', '170+ countries', 'Easy setup'],
      url: tokens.holafly ? `https://holafly.com/?ref=${tokens.holafly}` : 'https://holafly.com',
      color: 'bg-orange-500 text-white',
      badge: 'Unlimited Data'
    }
  ];

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-slate-600" />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 min-h-full bg-gradient-to-b from-slate-50 to-slate-100">
      <div className="flex items-center gap-4 mb-6">
        <Button 
          variant="outline" 
          size="icon" 
          className="border-gray-300 text-slate-700 hover:bg-slate-200" 
          onClick={handleBackClick}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex items-center gap-3">
          <Signal className="w-8 h-8 text-slate-800" />
          <h1 className="text-3xl font-bold text-slate-800">Get an eSIM for Your Trip</h1>
        </div>
      </div>
      
      <p className="text-lg text-slate-600 mb-8 max-w-3xl">
        Stay connected in 200+ countries with an eSIM. Avoid expensive roaming charges and get data as soon as you land - no physical SIM card needed!
      </p>

      {/* eSIM Providers - Now First */}
      <div className="mb-8">
        <h2 className="text-2xl font-semibold text-slate-800 mb-6">Choose Your eSIM Provider</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {esimProviders.map((provider) => (
            <Card key={provider.name} className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-2 border-transparent hover:border-slate-300 bg-white">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{provider.logo}</span>
                    <div>
                      <CardTitle className="text-xl flex items-center gap-2">
                        {provider.name}
                        {provider.badge && (
                          <Badge variant="secondary" className="text-xs">
                            {provider.badge}
                          </Badge>
                        )}
                      </CardTitle>
                    </div>
                  </div>
                  <ExternalLink className="w-5 h-5 text-slate-400 group-hover:text-slate-600" />
                </div>
                <p className="text-slate-600 mt-2">{provider.description}</p>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="mb-6">
                  <h4 className="font-medium text-slate-800 mb-3">Key Features:</h4>
                  <div className="grid grid-cols-2 gap-2">
                    {provider.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-slate-600">
                        <div className="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>
                <Button 
                  className={`w-full ${provider.color} hover:opacity-90`}
                  onClick={() => handleProviderClick(provider.url)}
                  size="lg"
                >
                  Browse {provider.name} Plans
                  <ExternalLink className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Benefits Section - Now Second */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {benefits.map((benefit, index) => (
          <Card key={index} className="bg-white/80 backdrop-blur-sm border-gray-200/50">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-700">
                {benefit.icon}
              </div>
              <h3 className="font-semibold text-slate-800 mb-2">{benefit.title}</h3>
              <p className="text-sm text-slate-600">{benefit.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* How it Works */}
      <Card className="bg-slate-100 border-slate-200">
        <CardHeader>
          <CardTitle className="text-xl text-slate-800 flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            How eSIMs Work
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="w-10 h-10 bg-slate-800 text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold">1</div>
              <h4 className="font-semibold text-slate-800 mb-2">Choose & Buy</h4>
              <p className="text-sm text-slate-600">Select your destination and data plan, then purchase online</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-slate-800 text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold">2</div>
              <h4 className="font-semibold text-slate-800 mb-2">Scan QR Code</h4>
              <p className="text-sm text-slate-600">Download the eSIM by scanning the QR code sent to your email</p>
            </div>
            <div>
              <div className="w-10 h-10 bg-slate-800 text-white rounded-full flex items-center justify-center mx-auto mb-3 font-bold">3</div>
              <h4 className="font-semibold text-slate-800 mb-2">Connect</h4>
              <p className="text-sm text-slate-600">Activate when you arrive and enjoy instant connectivity</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Affiliate Disclosure */}
      <div className="mt-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <p className="text-xs text-slate-500 text-center">
          <strong>Disclosure:</strong> TripGenius may earn a commission when you purchase through these links. 
          This helps us keep the app free while you get the same great prices.
        </p>
      </div>
    </div>
  );
}
