
import React, { useState, useEffect, useCallback } from 'react';
import { Trip } from '@/api/entities';
import { User } from '@/api/entities';
import { PackingList } from '@/api/entities';
import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, ArrowLeft, Edit, Trash2, Share2, Archive, Landmark } from 'lucide-react';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';
import { generatePackingList } from '@/api/functions';
import ItineraryHeader from '../components/itinerary/ItineraryHeader';
import ItineraryOverview from '../components/itinerary/ItineraryOverview';
import DailyItineraryView from '../components/itinerary/DailyItineraryView';
import ItineraryMapView from '../components/itinerary/ItineraryMapView';
import HotelRecommendations from '../components/itinerary/HotelRecommendations';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function ViewItinerary() {
  const { id: paramId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const id = paramId || searchParams.get('id');

  const [trip, setTrip] = useState(null);
  const [user, setUser] = useState(null);
  const [packingList, setPackingList] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessingList, setIsProcessingList] = useState(false);
  const [error, setError] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isOwner, setIsOwner] = useState(false);

  const loadData = useCallback(async () => {
    if (!id) {
      setError('No trip ID provided.');
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const tripData = await Trip.get(id);
      setTrip(tripData);

      try {
        const currentUser = await User.me();
        setUser(currentUser);
        const owner = currentUser?.email === tripData.created_by;
        setIsOwner(owner);

        if (owner) {
          const lists = await PackingList.filter({ trip_id: id });
          if (lists && lists.length > 0) {
            setPackingList(lists[0]);
          }
        }
      } catch (userError) {
        setUser(null);
        setIsOwner(false);
      }

    } catch (e) {
      setError('Failed to load trip. It might be private or may not exist.');
      toast.error('Could not load the requested itinerary.');
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleDeleteTrip = async () => {
    setIsDeleting(true);
    try {
      await Trip.delete(id);
      toast.success("Trip deleted successfully.");
      navigate(createPageUrl('MyTrips'));
    } catch (e) {
      toast.error("Failed to delete trip.");
      console.error(e);
      setIsDeleting(false);
    }
  };

  const handleShare = async () => {
    toast.info("Generating public link...");
    try {
      if (!trip.is_public) {
        const updatedTrip = await Trip.update(trip.id, { is_public: true });
        setTrip(updatedTrip);
      }
      const shareUrl = `${window.location.origin}${createPageUrl(`ViewItinerary/${trip.id}`)}`;
      navigator.clipboard.writeText(shareUrl);
      toast.success("Public share link copied to clipboard!");
    } catch (error) {
      console.error("Failed to generate share link:", error);
      toast.error("Could not create a public link. Please try again.");
    }
  };

  const handlePackingList = async () => {
    if (packingList) {
      navigate(createPageUrl('PackingListDetails') + `?id=${packingList.id}`);
      return;
    }

    setIsProcessingList(true);
    toast.info("Generating a personalized packing list...");

    try {
      const getActivities = () => {
        if (!trip.daily_itinerary) return 'General sightseeing';
        return trip.daily_itinerary
          .flatMap(day => day.activities?.map(act => act.name) || [])
          .filter(Boolean)
          .slice(0, 10)
          .join(', ');
      };

      const getDuration = () => {
        if (!trip.start_date || !trip.end_date) return 'a few days';
        const start = new Date(trip.start_date);
        const end = new Date(trip.end_date);
        const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
        return `${days} days`;
      };

      const getSeason = () => {
        if (!trip.start_date) return 'Unknown season';
        const month = new Date(trip.start_date).getMonth();
        if (month >= 2 && month <= 4) return 'Spring';
        if (month >= 5 && month <= 7) return 'Summer';
        if (month >= 8 && month <= 10) return 'Fall';
        return 'Winter';
      };

      const response = await generatePackingList({
        destination: trip.destination,
        duration: getDuration(),
        tripType: trip.budget || 'general travel',
        activities: getActivities(),
        season: getSeason(),
        accommodationType: trip.budget === 'luxury' ? 'luxury hotel' : trip.budget === 'budget' ? 'budget accommodation' : 'mid-range hotel',
        travelers: trip.travelers || 1,
        specialRequirements: '',
        trip_id: trip.id
      });

      if (response.data && response.data.success) {
        toast.success("Packing list generated successfully!");
        setPackingList(response.data.packingList);
        navigate(createPageUrl('PackingListDetails') + `?id=${response.data.packingList.id}`);
      } else {
        console.error('Packing list generation failed:', response);
        throw new Error(response.data?.error || 'Failed to generate packing list');
      }

    } catch (error) {
      console.error('Packing list generation failed:', error);
      toast.error('Could not generate packing list. Please try again.', {
        description: error.message
      });
    } finally {
      setIsProcessingList(false);
    }
  };

  // You can continue rendering the UI below this point (e.g., itinerary sections, buttons, etc.)
}