
import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trip } from '@/api/entities';
import { PackingList } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Archive, ListPlus, Sparkles, ArrowRight, Trash2, Shield, ExternalLink, IdCard } from 'lucide-react';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { generatePackingList } from '@/api/functions';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { cn } from '@/lib/utils';

const PackingListCard = ({ list, onDelete }) => (
  <Card className="group transition-all duration-300 hover:shadow-lg hover:border-slate-400">
    <CardContent className="p-6">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="font-bold text-lg text-slate-800">{list.name}</h3>
          <p className="text-sm text-slate-500 line-clamp-1">{list.description || 'No description'}</p>
          <p className="text-xs text-slate-400 mt-2">{list.items?.length || 0} items</p>
        </div>
        <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-500 hover:bg-red-50" onClick={(e) => { e.preventDefault(); e.stopPropagation(); onDelete(list.id); }}>
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
      <Link to={createPageUrl(`PackingListDetails?id=${list.id}`)}>
        <Button variant="outline" className="w-full mt-4">
          View List <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </Link>
    </CardContent>
  </Card>
);

const EntryRequirementsChecker = () => {
  const [destination, setDestination] = useState('');

  const handleCheckRequirements = () => {
    if (!destination.trim()) {
      toast.error("Please enter a destination first.");
      return;
    }
    
    // Format destination for Sherpa URL (remove spaces, handle special characters)
    const formattedDestination = encodeURIComponent(destination.trim());
    const sherpaUrl = `https://apply.joinsherpa.com/travel-restrictions?origin=US&destination=${formattedDestination}`;
    
    window.open(sherpaUrl, '_blank', 'noopener,noreferrer');
    toast.success(`Checking entry requirements for ${destination}...`);
  };

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200/50 shadow-lg">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-3 text-blue-900">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
            <Shield className="w-5 h-5 text-blue-600" />
          </div>
          Entry Requirements Checker
        </CardTitle>
        <CardDescription className="text-blue-700">
          Check visa requirements, COVID restrictions, and entry documents needed for your destination.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-3">
          <div className="flex-1">
            <Input
              placeholder="Enter destination (e.g., Japan, France, Thailand)"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="bg-white border-blue-200 focus:border-blue-400 text-slate-800"
              onKeyPress={(e) => e.key === 'Enter' && handleCheckRequirements()}
            />
          </div>
          <Button 
            onClick={handleCheckRequirements}
            className="bg-blue-600 hover:bg-blue-700 text-white shadow-md hover:shadow-lg transition-all duration-300"
          >
            <IdCard className="w-4 h-4 mr-2" />
            Check Requirements
            <ExternalLink className="w-4 h-4 ml-2" />
          </Button>
        </div>
        <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-xs text-blue-600 leading-relaxed">
            <strong>Powered by Sherpa:</strong> Get up-to-date visa requirements, COVID restrictions, and travel documents needed. Always verify with official sources before traveling.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default function PackingListsPage() {
  const [lists, setLists] = useState([]);
  const [trips, setTrips] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [listToDelete, setListToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    destination: '',
    duration: '',
    tripType: 'vacation',
    trip_id: ''
  });

  const loadLists = async () => {
    try {
      const packingData = await PackingList.list('-created_date');
      setLists(packingData || []);
    } catch (error) {
      console.error("Failed to load packing lists:", error);
      toast.error("Could not load your packing lists.");
    }
  };

  const loadTrips = async () => {
    try {
      const tripData = await Trip.list('-created_date');
      setTrips(tripData || []);
    } catch (error) {
      console.error("Failed to load trips:", error);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    Promise.all([loadLists(), loadTrips()]).finally(() => setIsLoading(false));
  }, []);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleTripSelectionChange = (tripId) => {
    const selectedTrip = trips.find(t => t.id === tripId);
    if (selectedTrip) {
      setFormData({
        destination: selectedTrip.destination,
        duration: calculateDuration(selectedTrip.start_date, selectedTrip.end_date),
        tripType: 'vacation',
        trip_id: tripId,
      });
    }
  };

  const calculateDuration = (start, end) => {
    if (!start || !end) return '';
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = Math.abs(endDate - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return `${diffDays} days`;
  };

  const handleGenerateList = async (e) => {
    e.preventDefault();
    if (!formData.destination) {
      toast.error("Please provide a destination to generate a list.");
      return;
    }
    setIsGenerating(true);
    toast.info("Generating your personalized packing list...", {
      description: `Hold tight, our AI is crafting the perfect list for ${formData.destination}.`
    });

    try {
      const { data } = await generatePackingList({
        destination: formData.destination,
        duration: formData.duration,
        tripType: formData.tripType,
        trip_id: formData.trip_id || null,
      });

      if (data.success && data.packingList) {
        toast.success("Your packing list is ready!");
        navigate(createPageUrl(`PackingListDetails?id=${data.packingList.id}`));
      } else {
        throw new Error(data.error || "AI failed to generate a valid list.");
      }
    } catch (error) {
      console.error("Failed to generate packing list:", error);
      toast.error("List generation failed.", {
        description: "The AI couldn't create a list. Please try being more specific or check your connection."
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  const handleDeleteClick = (id) => {
    setListToDelete(id);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!listToDelete) return;
    setIsDeleting(true);
    try {
      await PackingList.delete(listToDelete);
      toast.success("Packing list deleted.");
      await loadLists();
    } catch (error) {
      toast.error("Failed to delete list.");
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setListToDelete(null);
    }
  };

  return (
    <>
      <div className="p-6 bg-gradient-to-b from-slate-50 to-white min-h-full pb-28">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Packing Lists</h1>
            <p className="text-slate-600">Generate smart packing lists and check entry requirements for your travels.</p>
          </div>

          {/* Entry Requirements Checker - New Section */}
          <div className="mb-8">
            <EntryRequirementsChecker />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Archive className="w-6 h-6 text-slate-700" />
                    My Packing Lists
                  </CardTitle>
                   <CardDescription>
                    {isLoading ? "Loading your lists..." : `You have ${lists.length} packing lists.`}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="flex justify-center items-center h-48">
                      <Loader2 className="w-8 h-8 animate-spin text-slate-400" />
                    </div>
                  ) : lists.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {lists.map(list => (
                        <PackingListCard key={list.id} list={list} onDelete={handleDeleteClick} />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 border-2 border-dashed rounded-lg">
                      <p className="text-slate-500">You don't have any packing lists yet.</p>
                      <p className="text-slate-400 text-sm">Use the form to generate one with AI!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-1">
              <Card className="sticky top-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-violet-500" />
                    Generate New List
                  </CardTitle>
                  <CardDescription>Let AI create a personalized packing list for you.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleGenerateList} className="space-y-4">
                    <div>
                      <Label htmlFor="trip_id">Generate from a Trip (Optional)</Label>
                      <Select onValueChange={handleTripSelectionChange} disabled={isGenerating}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a saved trip" />
                        </SelectTrigger>
                        <SelectContent>
                          {trips.map(trip => (
                            <SelectItem key={trip.id} value={trip.id}>{trip.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="text-center text-xs text-slate-400">OR FILL MANUALLY</div>

                    <div>
                      <Label htmlFor="destination">Destination *</Label>
                      <Input id="destination" value={formData.destination} onChange={(e) => handleChange('destination', e.target.value)} placeholder="e.g., Tokyo, Japan" required disabled={isGenerating} />
                    </div>
                    <div>
                      <Label htmlFor="duration">Trip Duration</Label>
                      <Input id="duration" value={formData.duration} onChange={(e) => handleChange('duration', e.target.value)} placeholder="e.g., 7 days" disabled={isGenerating} />
                    </div>
                    <div>
                      <Label htmlFor="tripType">Type of Trip</Label>
                      <Select value={formData.tripType} onValueChange={(val) => handleChange('tripType', val)} disabled={isGenerating}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="vacation">Vacation</SelectItem>
                          <SelectItem value="business">Business</SelectItem>
                          <SelectItem value="adventure">Adventure</SelectItem>
                          <SelectItem value="backpacking">Backpacking</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button type="submit" className="w-full bg-gradient-aurora text-white" disabled={isGenerating}>
                      {isGenerating ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Generate List
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this packing list. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
              {isDeleting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
