

import React, { useState, useEffect } from 'react';
import TopHeader from './components/layout/TopHeader';
import BottomNav from './components/layout/BottomNav';
import LeftSidebar from './components/layout/LeftSidebar';
import CookieConsent from './components/CookieConsent';
import BookingDrawer from './components/booking/BookingDrawer';
import { cn } from '@/lib/utils';

export default function Layout({ children, currentPageName }) {
  const [leftSidebarOpen, setLeftSidebarOpen] = useState(false);
  const [bookingDrawerOpen, setBookingDrawerOpen] = useState(false);

  useEffect(() => {
    const leafletCssId = 'leaflet-css';
    if (!document.getElementById(leafletCssId)) {
      const link = document.createElement('link');
      link.id = leafletCssId;
      link.rel = 'stylesheet';
      link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
      link.integrity = 'sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=';
      link.crossOrigin = '';
      document.head.appendChild(link);
    }
    
    const consent = localStorage.getItem('cookieConsent');
    
    if (consent === 'accepted') {
      if (!window.gtag) {
        const gaScript = document.createElement("script");
        gaScript.async = true;
        gaScript.src = 'https://www.googletagmanager.com/gtag/js?id=G-9B2DP6LXN7';
        document.head.appendChild(gaScript);

        gaScript.onload = () => {
          window.dataLayer = window.dataLayer || [];
          function gtag(){window.dataLayer.push(arguments);}
          window.gtag = gtag;
          gtag('js', new Date());
          gtag('config', 'G-9B2DP6LXN7');
        };
      }

      if (!document.querySelector('script[src*="emrldtp.com"]')) {
        const travelScript = document.createElement("script");
        travelScript.async = true;
        travelScript.src = 'https://emrldtp.com/NDU2MTk4.js?t=456198';
        travelScript.setAttribute('data-noptimize', '1');
        travelScript.setAttribute('data-cfasync', 'false');
        travelScript.setAttribute('data-wpfc-render', 'false');
        document.head.appendChild(travelScript);
      }
    }
  }, []);

  useEffect(() => {
    if (typeof window.gtag === 'function' && currentPageName) {
      window.gtag('config', 'G-9B2DP6LXN7', {
        page_title: currentPageName,
        page_location: window.location.href
      });
    }
  }, [currentPageName]);

  const showNav = currentPageName !== 'TravelQuiz';

  return (
    <>
      <style>{`
        /* Refined Professional Theme with Enhanced Aurora Elements */
        :root {
          /* Core Colors - Slightly refined */
          --background: 218 15% 98%; /* Softer, warmer white */
          --foreground: 222 87% 3%; /* Deeper black for better contrast */
          
          --card: 0 0% 100%;
          --card-foreground: 222 87% 3%;
          
          --popover: 0 0% 100%;
          --popover-foreground: 222 87% 3%;
          
          --primary: 222 50% 8%; /* Slightly deeper primary */
          --primary-foreground: 210 45% 99%;
          
          --secondary: 210 45% 97%; /* Softer secondary */
          --secondary-foreground: 222 50% 8%;
          
          --muted: 210 45% 97%;
          --muted-foreground: 215 18% 44%; /* Better contrast */
          
          --accent: 210 45% 97%;
          --accent-foreground: 222 50% 8%;
          
          --destructive: 0 85% 58%;
          --destructive-foreground: 210 45% 99%;
          
          --border: 214 35% 92%; /* Slightly more defined borders */
          --input: 214 35% 92%;
          --ring: 222 50% 8%;
          
          --radius: 0.625rem; /* Slightly larger radius for modern feel */

          /* Enhanced Aurora Colors with Better Harmony */
          --electric-blue: #0ea5e9; /* Sky blue - more harmonious */
          --neon-turquoise: #06b6d4; /* Cyan - consistent with theme */
          --vivid-purple: #8b5cf6; /* Violet - softer but vibrant */
          --neon-pink: #ec4899; /* Pink - balanced intensity */
          
          /* New Accent Colors for Depth */
          --aurora-gradient-1: linear-gradient(135deg, #0ea5e9 0%, #06b6d4 50%, #8b5cf6 100%);
          --aurora-gradient-2: linear-gradient(135deg, #8b5cf6 0%, #ec4899 50%, #f97316 100%);
          --aurora-shadow: 0 8px 32px rgba(14, 165, 233, 0.15);
        }
        
        /* Enhanced Typography with Better Hierarchy */
        body {
          background-color: hsl(var(--background));
          color: hsl(var(--foreground));
          font-size: 14px;
          line-height: 1.6; /* Improved readability */
          font-weight: 400;
          letter-spacing: -0.01em; /* Subtle tightening for modern feel */
        }

        /* Refined Heading Sizes with Better Spacing */
        h1 { 
          font-size: 1.875rem; 
          line-height: 1.2; 
          font-weight: 700;
          letter-spacing: -0.025em;
          margin-bottom: 0.5em;
        }
        h2 { 
          font-size: 1.5rem; 
          line-height: 1.3; 
          font-weight: 600;
          letter-spacing: -0.02em;
          margin-bottom: 0.4em;
        }
        h3 { 
          font-size: 1.25rem; 
          line-height: 1.4; 
          font-weight: 600;
          letter-spacing: -0.015em;
          margin-bottom: 0.35em;
        }
        h4 { 
          font-size: 1.125rem; 
          line-height: 1.4; 
          font-weight: 500;
          margin-bottom: 0.3em;
        }
        h5 { 
          font-size: 1rem; 
          line-height: 1.5; 
          font-weight: 500;
          margin-bottom: 0.25em;
        }
        h6 { 
          font-size: 0.875rem; 
          line-height: 1.5; 
          font-weight: 500;
          margin-bottom: 0.2em;
        }

        /* Refined Text Classes with Consistent Spacing */
        p { 
          font-size: 0.875rem; 
          line-height: 1.6; 
          margin-bottom: 1em;
          color: hsl(var(--foreground));
        }
        
        .text-xs { font-size: 0.625rem; line-height: 1.4; }
        .text-sm { font-size: 0.75rem; line-height: 1.5; }
        .text-base { font-size: 0.875rem; line-height: 1.6; }
        .text-lg { font-size: 1rem; line-height: 1.6; }
        .text-xl { font-size: 1.125rem; line-height: 1.6; }
        .text-2xl { font-size: 1.25rem; line-height: 1.5; }
        .text-3xl { font-size: 1.5rem; line-height: 1.4; }
        .text-4xl { font-size: 1.875rem; line-height: 1.3; }
        .text-5xl { font-size: 2.25rem; line-height: 1.2; }
        .text-6xl { font-size: 2.5rem; line-height: 1.1; }

        /* Enhanced Aurora Gradients with Smoother Transitions */
        .bg-gradient-aurora {
          background: var(--aurora-gradient-1);
          background-size: 200% 200%;
          animation: aurora-shift 6s ease-in-out infinite;
        }

        .text-gradient-aurora {
          background: var(--aurora-gradient-1);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
          background-size: 200% 200%;
          animation: aurora-shift 6s ease-in-out infinite;
        }

        @keyframes aurora-shift {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        
        /* Enhanced Aurora Colors with Better Integration */
        .text-electric-blue { color: var(--electric-blue); }
        .text-neon-turquoise { color: var(--neon-turquoise); }
        .text-vivid-purple { color: var(--vivid-purple); }
        .text-neon-pink { color: var(--neon-pink); }
        
        /* Improved Button Styles */
        .btn-aurora {
          background: var(--aurora-gradient-1);
          color: white;
          border: none;
          box-shadow: var(--aurora-shadow);
          transition: all 0.3s ease;
        }
        
        .btn-aurora:hover {
          transform: translateY(-1px);
          box-shadow: 0 12px 40px rgba(14, 165, 233, 0.25);
        }
        
        /* Refined Scrollbar with Aurora Touch */
        ::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        ::-webkit-scrollbar-track {
          background: hsl(var(--background));
        }
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, var(--electric-blue), var(--vivid-purple));
          border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, var(--neon-turquoise), var(--neon-pink));
        }
        
        /* Enhanced Card Styles */
        .card-aurora {
          background: rgba(255, 255, 255, 0.7);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(255, 255, 255, 0.2);
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        
        /* Smooth Transitions for Interactive Elements */
        button, .interactive {
          transition: all 0.2s ease;
        }
        
        button:hover:not(:disabled) {
          transform: translateY(-1px);
        }
        
        /* Enhanced Focus Styles for Accessibility */
        :focus-visible {
          outline: 2px solid var(--electric-blue);
          outline-offset: 2px;
        }
        
        /* Leaflet Map Enhancements */
        .leaflet-container {
          height: 100%;
          width: 100%;
          z-index: 0;
          color: #333;
          font-size: 0.75rem;
          border-radius: var(--radius);
          overflow: hidden;
        }

        /* Loading Animation Enhancement */
        .loading-spinner {
          animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        /* Responsive Enhancements */
        @media (max-width: 768px) {
          body { font-size: 13px; }
          h1 { font-size: 1.5rem; line-height: 1.3; }
          h2 { font-size: 1.25rem; line-height: 1.4; }
          h3 { font-size: 1.125rem; line-height: 1.4; }
          .text-3xl { font-size: 1.25rem; }
          .text-4xl { font-size: 1.5rem; }
          .text-5xl { font-size: 1.875rem; }
          .text-6xl { font-size: 2rem; }
        }

        /* Dark Mode Support Preparation */
        @media (prefers-color-scheme: dark) {
          :root {
            /* Future dark mode variables */
          }
        }

        /* Improved Animation Performance */
        .animate-aurora {
          will-change: background-position;
        }

        /* Enhanced Glass Morphism */
        .glass {
          background: rgba(255, 255, 255, 0.8);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        /* Better spacing utilities */
        .space-y-6 > * + * {
          margin-top: 1.5rem;
        }
        
        .space-y-8 > * + * {
          margin-top: 2rem;
        }
      `}</style>
      <div className="min-h-screen w-full font-sans bg-gradient-to-br from-slate-50/80 to-white/90">
        <LeftSidebar isOpen={leftSidebarOpen} setIsOpen={setLeftSidebarOpen} />
        <BookingDrawer isOpen={bookingDrawerOpen} setIsOpen={setBookingDrawerOpen} />
        
        <div className="flex flex-col h-screen">
          <TopHeader
            onMenuClick={() => setLeftSidebarOpen(true)}
            onBookingClick={() => setBookingDrawerOpen(true)}
          />
          
          <main className={cn(
            "flex-1 overflow-y-auto bg-gradient-to-br from-slate-50/80 to-white/90 relative",
            showNav && "pb-20",
            // Smooth scroll behavior
            "scroll-smooth"
          )}>
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--electric-blue)_0%,_transparent_50%)] opacity-3 pointer-events-none" />
            <div className="relative z-10 h-full">
              {children}
            </div>
          </main>
        </div>
        
        {showNav && <BottomNav />}
        <CookieConsent />
      </div>
    </>
  );
}

