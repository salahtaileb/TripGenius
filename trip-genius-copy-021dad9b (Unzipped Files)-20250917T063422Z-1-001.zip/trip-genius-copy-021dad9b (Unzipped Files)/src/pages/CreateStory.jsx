import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Upload, X, Loader2, ImagePlus, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { User } from '@/api/entities';
import { PhotoStory } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { createPageUrl } from '@/utils';

export default function CreateStoryPage() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [photos, setPhotos] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    User.me().then(setUser).catch(() => navigate('/'));
  }, [navigate]);

  const handleFileSelect = (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    handleUpload(files);
  };

  const handleUpload = async (files) => {
    setIsUploading(true);
    toast.info(`Uploading ${files.length} photo(s)...`);

    const uploadPromises = files.map(file => UploadFile({ file }));

    try {
      const results = await Promise.all(uploadPromises);
      const newPhotos = results.map(res => ({ url: res.file_url }));
      setPhotos(prev => [...prev, ...newPhotos]);
      toast.success('Photos uploaded successfully!');
    } catch (error) {
      console.error('Error uploading files:', error);
      toast.error('Some photos failed to upload. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const removePhoto = (index) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!title || photos.length === 0) {
      toast.error('Please add a title and at least one photo.');
      return;
    }
    
    setIsSubmitting(true);
    toast.info('Publishing your story...');

    try {
      await PhotoStory.create({
        title,
        description,
        location,
        photo_urls: photos.map(p => p.url),
        author_name: user.full_name,
        author_avatar_url: user.profile_picture_url || '',
      });
      toast.success('Your photo story has been published!');
      navigate(createPageUrl('Blogs'));
    } catch (error) {
      console.error('Failed to create photo story:', error);
      toast.error('Failed to publish your story. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 bg-gradient-to-b from-slate-50 to-slate-100 min-h-full pb-32">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="icon" className="border-gray-300 text-slate-700 hover:bg-slate-200" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex items-center gap-3">
          <ImagePlus className="w-8 h-8 text-electric-blue" />
          <h1 className="text-3xl font-bold text-slate-800">Create a Photo Story</h1>
        </div>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="bg-glass border border-electric-blue/20">
              <CardHeader>
                <CardTitle className="text-dark-readable">Story Details</CardTitle>
                <CardDescription className="text-medium-grey">Tell everyone about your experience.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title" className="text-dark-readable">Title</Label>
                  <Input 
                    id="title" 
                    value={title} 
                    onChange={e => setTitle(e.target.value)} 
                    placeholder="e.g., My Adventure in the Alps" 
                    required 
                    className="bg-white border-gray-200 text-dark-readable story-input placeholder:text-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="location" className="text-dark-readable">Location</Label>
                  <Input 
                    id="location" 
                    value={location} 
                    onChange={e => setLocation(e.target.value)} 
                    placeholder="e.g., Swiss Alps, Switzerland" 
                    className="bg-white border-gray-200 text-dark-readable story-input placeholder:text-gray-500"
                  />
                </div>
                <div>
                  <Label htmlFor="description" className="text-dark-readable">Your Story</Label>
                  <Textarea 
                    id="description" 
                    value={description} 
                    onChange={e => setDescription(e.target.value)} 
                    placeholder="Describe your journey, the moments you captured, and what made it special." 
                    rows={6} 
                    className="bg-white border-gray-200 text-dark-readable story-input placeholder:text-gray-500"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="space-y-6">
            <Card className="bg-glass border border-vivid-purple/20">
              <CardHeader>
                <CardTitle className="text-dark-readable">Your Photos</CardTitle>
                <CardDescription className="text-medium-grey">Add the photos that tell your story.</CardDescription>
              </CardHeader>
              <CardContent>
                <div 
                  className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:bg-light-grey/50 hover:border-vivid-purple transition-colors"
                  onClick={() => fileInputRef.current.click()}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    className="hidden"
                    multiple
                    accept="image/*"
                  />
                  {isUploading ? (
                    <Loader2 className="w-8 h-8 mx-auto text-electric-blue animate-spin" />
                  ) : (
                    <Upload className="w-8 h-8 mx-auto text-electric-blue" />
                  )}
                  <p className="mt-2 text-sm text-medium-grey">
                    {isUploading ? 'Uploading...' : 'Click or drag photos to upload'}
                  </p>
                  <p className="text-xs text-gray-400">PNG, JPG, GIF up to 10MB</p>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-4">
                  {photos.map((photo, index) => (
                    <div key={index} className="relative group">
                      <img src={photo.url} alt={`upload-preview-${index}`} className="w-full h-24 object-cover rounded-md" />
                      <Button
                        size="icon"
                        variant="destructive"
                        className="absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => removePhoto(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Submit Button Card - Now clearly separate and visible */}
            <Card className="bg-white/90 border border-green-200/50 shadow-lg">
              <CardContent className="p-6">
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform duration-300 h-14 text-lg font-semibold" 
                  disabled={isSubmitting || isUploading}
                >
                  {isSubmitting ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : null}
                  {isSubmitting ? 'Publishing...' : 'Publish Story'}
                </Button>
                {(!title || photos.length === 0) && (
                  <p className="text-xs text-gray-500 text-center mt-2">
                    Please add a title and at least one photo to publish
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </form>

      <style jsx>{`
        /* Enhanced autofill override specifically for story inputs */
        .story-input:-webkit-autofill,
        .story-input:-webkit-autofill:hover,
        .story-input:-webkit-autofill:focus,
        .story-input:-webkit-autofill:active {
          -webkit-box-shadow: 0 0 0px 1000px #ffffff inset !important;
          -webkit-text-fill-color: #1E1E1E !important;
          box-shadow: 0 0 0px 1000px #ffffff inset !important;
          background-color: #ffffff !important;
        }
      `}</style>
    </div>
  );
}