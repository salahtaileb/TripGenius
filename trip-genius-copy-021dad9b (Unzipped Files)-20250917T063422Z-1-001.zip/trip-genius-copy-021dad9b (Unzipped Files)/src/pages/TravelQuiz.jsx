
import React, { useState, useEffect, useMemo } from 'react';
import { User } from '@/api/entities';
import { TravelProfile } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowLeft, BrainCircuit, Loader2, Sparkles, RefreshCw, PieChart } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { generateTripPlan } from '@/api/functions';

const questions = [
  {
    title: "What's your travel vibe?",
    options: [
      {
        emoji: "🏖️",
        text: "Relax & Recharge",
        subtitle: "Luxury resorts, spas, beach time",
        value: "relax_recharge",
        budgetWeight: "premium"
      },
      {
        emoji: "🏛️",
        text: "Culture & Exploration",
        subtitle: "Museums, historical sites, local tours",
        value: "culture_exploration",
        budgetWeight: "balanced"
      },
      {
        emoji: "🎢",
        text: "Adventure & Thrills",
        subtitle: "Hiking, unique experiences, nightlife",
        value: "adventure_thrills",
        budgetWeight: "balanced"
      }
    ],
    key: 'travel_vibe'
  },
  {
    title: "How do you like to sleep?",
    options: [
      {
        emoji: "🏨",
        text: "Luxury Boutique",
        subtitle: "4-5 star hotels, unique stays",
        value: "luxury_boutique",
        budgetWeight: "premium"
      },
      {
        emoji: "🛌",
        text: "Comfort & Value",
        subtitle: "Clean, central 3-star hotels or apartments",
        value: "comfort_value",
        budgetWeight: "balanced"
      },
      {
        emoji: "🛋️",
        text: "Budget-Friendly",
        subtitle: "Hostels, budget chains, prioritize location",
        value: "budget_friendly",
        budgetWeight: "budget"
      }
    ],
    key: 'accommodation_preference'
  },
  {
    title: "What's your dining style?",
    options: [
      {
        emoji: "🍽️",
        text: "Fine Dining",
        subtitle: "Trying acclaimed restaurants",
        value: "fine_dining",
        budgetWeight: "premium"
      },
      {
        emoji: "🍜",
        text: "Local Eateries",
        subtitle: "Street food, family-run cafes",
        value: "local_eateries",
        budgetWeight: "balanced"
      },
      {
        emoji: "🛒",
        text: "Mix & Prepare",
        subtitle: "Cooking some meals, eating out sometimes",
        value: "mix_prepare",
        budgetWeight: "budget"
      }
    ],
    key: 'dining_style'
  },
  {
    title: "How will you get around?",
    options: [
      {
        emoji: "🚕",
        text: "Convenience",
        subtitle: "Taxis, ride-shares",
        value: "convenience",
        budgetWeight: "premium"
      },
      {
        emoji: "🚆",
        text: "Public Transport",
        subtitle: "Trains, buses, metro",
        value: "public_transport",
        budgetWeight: "balanced"
      },
      {
        emoji: "🚶",
        text: "Walk & Explore",
        subtitle: "Prioritize walkable cities",
        value: "walk_explore",
        budgetWeight: "budget"
      }
    ],
    key: 'transportation_style'
  },
  {
    title: "Shopping plans?",
    options: [
      {
        emoji: "🛍️",
        text: "Souvenirs & Gifts",
        subtitle: "Budget for shopping",
        value: "souvenirs_gifts",
        budgetWeight: "premium"
      },
      {
        emoji: "📸",
        text: "Experiences > Things",
        subtitle: "Spend on activities, not items",
        value: "experiences_over_things",
        budgetWeight: "balanced"
      },
      {
        emoji: "✋",
        text: "Window Shopping",
        subtitle: "No major shopping planned",
        value: "window_shopping",
        budgetWeight: "budget"
      }
    ],
    key: 'shopping_plans'
  },
  {
    title: "How planned do you like your days?",
    options: [
      {
        emoji: "🗓️",
        text: "Fully Booked",
        subtitle: "Guided tours, scheduled activities",
        value: "fully_booked",
        budgetWeight: "premium"
      },
      {
        emoji: "🤸",
        text: "Flexible & Spontaneous",
        subtitle: "Maybe 1-2 activities, then explore",
        value: "flexible_spontaneous",
        budgetWeight: "balanced"
      },
      {
        emoji: "😴",
        text: "Go with the Flow",
        subtitle: "No plans, relax and see what happens",
        value: "go_with_flow",
        budgetWeight: "budget"
      }
    ],
    key: 'planning_style'
  }
];

const budgetAllocations = {
  premium: {
    flights: 25,
    accommodation: 35,
    food: 25,
    activities: 10,
    transportation: 3,
    shopping: 2
  },
  balanced: {
    flights: 30,
    accommodation: 30,
    food: 20,
    activities: 15,
    transportation: 3,
    shopping: 2
  },
  budget: {
    flights: 35,
    accommodation: 20,
    food: 15,
    activities: 20,
    transportation: 5,
    shopping: 5
  }
};

const travelSummaries = {
  premium: "You enjoy the finer things in travel - luxury accommodations, exquisite dining, and premium experiences. You value comfort and are willing to invest in high-quality travel moments.",
  balanced: "You're a smart traveler who seeks the perfect balance of comfort, culture, and value. You appreciate authentic experiences while maintaining reasonable comfort levels.",
  budget: "You're an adventurous, resourceful traveler who prioritizes experiences over luxury. You love exploring like a local and making every dollar count for maximum adventure."
};

export default function TravelQuizPage() {
  const [answers, setAnswers] = useState({});
  const [showResult, setShowResult] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [user, setUser] = useState(null);
  const [result, setResult] = useState(null);
  const navigate = useNavigate();

  const [searchParams] = useSearchParams();
  const returnToChat = searchParams.get('returnToChat');

  const [destination, setDestination] = useState(searchParams.get('destination') || '');
  const [tripType, setTripType] = useState(searchParams.get('tripType') || '');
  const [interests, setInterests] = useState(searchParams.get('interests')?.split(',').map(i => i.trim()) || []);

  const [isGenerating, setIsGenerating] = useState(false);
  const [generationError, setGenerationError] = useState(null);

  useEffect(() => {
    User.me().then(setUser).catch(() => navigate('/'));
  }, [navigate]);

  const handleAnswer = (key, value) => {
    const selectedOption = questions.find(q => q.key === key)?.options.find(opt => opt.value === value);
    if (selectedOption) {
      setAnswers(prev => ({
        ...prev,
        [key]: { value, budgetWeight: selectedOption.budgetWeight }
      }));
    }
  };

  const calculateBudgetTier = () => {
    const weights = Object.values(answers).map(a => a.budgetWeight);
    const premiumCount = weights.filter(w => w === 'premium').length;
    const budgetCount = weights.filter(w => w === 'budget').length;

    if (premiumCount >= 3) return 'premium';
    if (budgetCount >= 3) return 'budget';
    return 'balanced';
  };

  const handleSubmit = async () => {
    if (!user) {
        toast.error('User not authenticated. Please log in.');
        return; 
    }
    if (Object.keys(answers).length < questions.length) {
      toast.error('Please answer all questions before continuing.');
      return; 
    }

    setIsSubmitting(true);
    toast.info("Analyzing your travel style and saving profile...");

    const budgetTier = calculateBudgetTier();
    const travelVibe = answers.travel_vibe?.value;
    const travelSummary = travelSummaries[budgetTier] || "You're a unique traveler, ready for anything!";
    const budgetAllocation = budgetAllocations[budgetTier];
    
    // Map all answer values as potential interests from the quiz
    const interestsFromAnswers = Object.values(answers).map(a => a.value).filter(Boolean);

    try {
      const profileData = {
        travel_vibe: answers.travel_vibe?.value,
        accommodation_preference: answers.accommodation_preference?.value,
        dining_style: answers.dining_style?.value,
        transportation_style: answers.transportation_style?.value,
        shopping_plans: answers.shopping_plans?.value,
        planning_style: answers.planning_style?.value,
        budget_tier: budgetTier,
        budget_allocation: budgetAllocation,
        travel_summary: travelSummary,
        completed_at: new Date().toISOString(),
        user_email: user.email,
      };

      const existingProfiles = await TravelProfile.filter({ user_email: user.email });
      if (existingProfiles.length > 0) {
        await TravelProfile.update(existingProfiles[0].id, profileData);
      } else {
        await TravelProfile.create(profileData);
      }
      
      toast.success("Travel profile saved!");
      
      // Set result after profile is saved, before potential trip generation
      const resultData = { budgetTier, travelVibe: answers.travel_vibe?.value, travelSummary, budgetAllocation, interestsFromAnswers };
      setResult(resultData);
      setShowResult(true);

    } catch (error) {
      console.error("Failed to save travel profile:", error);
      toast.error("Could not save your preferences.", {
        description: error.message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGenerateTrip = async () => {
    if (!result) {
        toast.error("Travel profile not loaded. Please complete the quiz first.");
        return;
    }
    if (!destination) {
      toast.error("No destination provided to generate a trip.");
      return;
    }

    setIsGenerating(true);
    setGenerationError(null);
    toast.info("Hold tight! Our AI is crafting your personalized trip...", {
      duration: 10000,
    });
    
    // Combine existing interests from search params with those derived from quiz answers
    const combinedInterests = [...new Set([...interests, ...(result.interestsFromAnswers || [])])];

    try {
      const response = await generateTripPlan({
        destination: destination,
        tripType: tripType,
        interests: combinedInterests,
        budgetTier: result.budgetTier,
        travelVibe: result.travelVibe,
        travelStyle: answers.planning_style?.value // Using planning_style as 'travelStyle' for AI generation
      });

      if (response.data.error || !response.data.success) {
        throw new Error(response.data.error || 'The AI failed to generate a valid plan. Please try again.');
      }
      
      const newTrip = response.data.trip;
      toast.success("Your personalized trip is ready!", {
        description: `Redirecting you to your itinerary for ${newTrip.name}.`
      });
      navigate(createPageUrl(`ViewItinerary`, { id: newTrip.id }));

    } catch (error) {
      console.error('Failed to generate trip plan:', error);
      toast.error("Trip Generation Failed", {
        description: error.message || "The AI couldn't create a plan. Please try again or adjust your preferences.",
        duration: 10000,
      });
      setGenerationError(error.message || "An unknown error occurred during trip generation. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRetake = () => {
    setAnswers({});
    setShowResult(false);
    setResult(null);
    setIsGenerating(false);
    setGenerationError(null);
    // Clearing URL params is optional here; keeping them allows re-generating a trip with same initial inputs
    // navigate(window.location.pathname, { replace: true }); 
  };

  const completedQuestions = Object.keys(answers).length;
  const progress = (completedQuestions / questions.length) * 100;

  const renderResult = () => (
    <div className="w-full max-w-2xl mx-auto">
      <Card className="bg-white border-2 border-black shadow-xl">
        <CardHeader className="text-center p-8">
          <div className="w-20 h-20 rounded-full bg-black flex items-center justify-center mx-auto mb-6">
            <PieChart className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold text-slate-800 mb-4">
            Your Travel Style: {result.budgetTier.charAt(0).toUpperCase() + result.budgetTier.slice(1)}
          </CardTitle>
          <p className="text-slate-600 mb-6">{result.travelSummary}</p>

          <div className="bg-slate-50 rounded-lg p-6 mb-6">
            <h3 className="font-bold text-slate-800 mb-4">Recommended Budget Allocation</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              {Object.entries(result.budgetAllocation).map(([category, percentage]) => (
                <div key={category} className="flex justify-between">
                  <span className="capitalize text-slate-600">{category}:</span>
                  <span className="font-semibold text-slate-800">{percentage}%</span>
                </div>
              ))}
            </div>
          </div>

          {destination ? ( // Only show trip generation if a destination was provided in search params
            <div className="mt-8 p-6 bg-slate-100 rounded-lg border border-slate-200">
              <h3 className="text-xl font-bold text-center text-slate-800 mb-4">Your Personalized Plan</h3>
              <p className="text-center text-slate-600 mb-6">
                Ready to see the perfect trip we've designed for you in <span className="font-bold">{destination}</span>?
              </p>
              <div className="flex justify-center">
                <Button 
                  size="lg" 
                  className="bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform duration-300"
                  onClick={handleGenerateTrip}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Generating Your Trip...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Generate My Trip
                    </>
                  )}
                </Button>
              </div>
              {generationError && (
                <div className="mt-4 text-center text-red-600 bg-red-100 p-3 rounded-md">
                  <p><strong>Error:</strong> {generationError}</p>
                  <p className="text-sm">Please try generating the trip again.</p>
                </div>
              )}
            </div>
          ) : ( // If no destination, show option to go to chat or home/explore destinations
            <div className="text-center mt-6">
              <p className="text-slate-600 mb-4">Your profile is updated. What would you like to do next?</p>
              <div className="flex justify-center gap-4">
                {returnToChat === 'true' ? (
                  <Button
                    onClick={() => navigate(createPageUrl('Chat', { fromQuiz: 'true' }))}
                    className="bg-black text-white hover:bg-slate-800"
                  >
                      Go to AI Assistant
                  </Button>
                ) : (
                  <Link to={createPageUrl('Home')}>
                    <Button className="bg-black text-white hover:bg-slate-800">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Explore Destinations
                    </Button>
                  </Link>
                )}
              </div>
            </div>
          )}
          
          <div className="mt-8 text-center">
            <Button onClick={handleRetake} variant="outline" className="border-slate-300">
              <RefreshCw className="w-4 h-4 mr-2"/>
              Retake Quiz
            </Button>
          </div>
        </CardHeader>
      </Card>
    </div>
  );

  const renderQuiz = () => (
    <>
      <div className="mb-8">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-slate-600">{completedQuestions} of {questions.length} questions answered</span>
          <span className="text-sm font-medium text-slate-800">{Math.round(progress)}% complete</span>
        </div>
        <Progress value={progress} className="w-full [&>div]:bg-slate-800" />
      </div>

      <Card className="bg-white border-gray-200 shadow-lg mb-8">
        <CardHeader>
          <CardTitle className="text-xl text-slate-800">Travel Style Questionnaire</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {questions.map((question) => (
            <div key={question.key} className="space-y-3">
              <label className="text-base font-medium text-slate-800">{question.title}</label>
              <Select
                value={answers[question.key]?.value || ""}
                onValueChange={(value) => handleAnswer(question.key, value)}
              >
                <SelectTrigger className="w-full h-12">
                  <SelectValue placeholder="Select your preference..." />
                </SelectTrigger>
                <SelectContent>
                  {question.options.map((option) => (
                    <SelectItem key={option.value} value={option.value} className="py-3">
                      <div className="flex items-center gap-3 w-full">
                        <span className="text-xl">{option.emoji}</span>
                        <div className="flex-1">
                          <div className="font-medium text-slate-800">{option.text}</div>
                          <div className="text-sm text-slate-600">{option.subtitle}</div>
                        </div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/80 backdrop-blur-sm border-t border-slate-200 z-10">
        <div className="max-w-2xl mx-auto text-center">
          <Button
            onClick={handleSubmit}
            disabled={Object.keys(answers).length < questions.length || isSubmitting}
            size="lg"
            className="bg-slate-800 text-white hover:bg-slate-900 px-8 w-full md:w-auto"
          >
            {isSubmitting && <Loader2 className="w-5 h-5 mr-2 animate-spin" />}
            {isSubmitting ? 'Processing...' : 'Get My Travel Style & Budget Plan'}
          </Button>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 p-6 pb-28">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex items-center justify-between">
          <Button
            variant="ghost"
            size="icon"
            // Adjusted back button logic: go back to quiz if on result page, else navigate home/chat
            onClick={() => showResult ? setShowResult(false) : navigate(returnToChat ? createPageUrl('Chat') : createPageUrl('Home'))}
            className={cn(
              "group relative w-12 h-12 rounded-2xl border-2 backdrop-blur-sm flex items-center justify-center transition-all duration-300 transform hover:scale-105",
              "bg-gradient-to-br from-vivid-purple via-neon-pink to-electric-blue border-white/40 shadow-lg"
            )}
            style={{
              boxShadow: '0 8px 25px rgba(0,0,0,0.15), 0 0 20px rgba(157, 0, 255, 0.4)'
            }}
          >
            <ArrowLeft className="w-5 h-5 text-white drop-shadow-lg group-hover:scale-110 transition-transform" />
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
          </Button>
          <div className="flex items-center gap-3">
            <BrainCircuit className="w-8 h-8 text-slate-800" />
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-slate-800">Travel Style Quiz</h1>
              {returnToChat === 'true' && !showResult && ( // Only show this message if it's from chat AND not on results page
                <p className="text-sm text-slate-600">Personalizing your AI assistant...</p>
              )}
            </div>
          </div>
          <div className="w-12"></div> {/* Spacer to balance header */}
        </div>

        {showResult && result ? renderResult() : renderQuiz()}
      </div>
    </div>
  );
}
