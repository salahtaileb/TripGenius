import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Car, ExternalLink, Zap, Users, Star, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { User } from '@/api/entities';
import { cn } from '@/lib/utils';

const rideOptions = [
  {
    name: 'Uber',
    description: 'Most popular ride-hailing service worldwide',
    icon: <Car className="w-6 h-6" />,
    color: 'from-slate-800 to-slate-900',
    textColor: 'text-white',
    features: ['Reliable', 'Fast pickup', 'Multiple options'],
    baseUrl: 'https://m.uber.com/ul'
  },
  {
    name: 'Lyft',
    description: 'Friendly rides with great customer service',
    icon: <Users className="w-6 h-6" />,
    color: 'from-pink-500 to-purple-600',
    textColor: 'text-white',
    features: ['Friendly drivers', 'Good for groups', 'Competitive rates'],
    baseUrl: 'https://ride.lyft.com'
  },
  {
    name: 'Bolt',
    description: 'Fast and affordable rides in many cities',
    icon: <Zap className="w-6 h-6" />,
    color: 'from-green-500 to-emerald-600',
    textColor: 'text-white',
    features: ['Quick booking', 'Affordable', 'Growing network'],
    baseUrl: 'https://bolt.eu'
  },
  {
    name: 'Local Taxi',
    description: 'Traditional taxi services in your area',
    icon: <Star className="w-6 h-6" />,
    color: 'from-amber-500 to-orange-600',
    textColor: 'text-white',
    features: ['Local knowledge', 'Cash accepted', 'Licensed drivers'],
    baseUrl: null
  }
];

export default function OrderCabPage() {
  const navigate = useNavigate();
  const [userLocation, setUserLocation] = useState({ latitude: '', longitude: '' });
  const [destination, setDestination] = useState('');

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const currentUser = await User.me();
        if (currentUser.last_known_location) {
          setUserLocation({
            latitude: currentUser.last_known_location.latitude,
            longitude: currentUser.last_known_location.longitude
          });
        }
      } catch (error) {
        console.warn("Could not fetch user location.");
      }
    };

    fetchUser();
  }, []);

  const handleRideSelection = (service) => {
    if (!destination.trim()) {
      toast.error("Please enter a destination address first.");
      return;
    }

    if (service.name === 'Local Taxi') {
      toast.info("Contact your local taxi service or look for taxis on the street.");
      return;
    }

    let serviceUrl;
    
    if (service.name === 'Uber') {
      serviceUrl = new URL(service.baseUrl);
      if (userLocation.latitude && userLocation.longitude) {
        serviceUrl.searchParams.set('action', 'setPickup');
        serviceUrl.searchParams.set('pickup[latitude]', userLocation.latitude);
        serviceUrl.searchParams.set('pickup[longitude]', userLocation.longitude);
        serviceUrl.searchParams.set('pickup[nickname]', 'My Current Location');
      }
      serviceUrl.searchParams.set('dropoff[formatted_address]', destination);
    } else {
      serviceUrl = service.baseUrl;
    }

    window.open(serviceUrl, '_blank', 'noopener,noreferrer');
    toast.success(`Opening ${service.name}...`);
  };

  return (
    <div className="p-6 min-h-full pb-32 bg-gradient-to-br from-slate-50 via-indigo-50 to-violet-50">
      <div className="max-w-4xl mx-auto">
        {/* Enhanced Header with Aurora Colors */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="icon" 
            className={cn(
              "group relative w-12 h-12 rounded-2xl border-2 backdrop-blur-sm flex items-center justify-center transition-all duration-300 transform hover:scale-105",
              "bg-gradient-to-br from-electric-blue via-neon-turquoise to-vivid-purple border-white/40 shadow-lg hover:shadow-xl"
            )}
            onClick={() => navigate(-1)}
          >
            <ArrowLeft className="w-5 h-5 text-white drop-shadow-lg group-hover:scale-110 transition-transform" />
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />
          </Button>
          
          <div className="flex items-center gap-4">
            <div className={cn(
              "relative w-16 h-16 rounded-3xl border-2 backdrop-blur-sm flex items-center justify-center",
              "bg-gradient-to-br from-electric-blue via-neon-turquoise to-vivid-purple border-white/40 shadow-xl"
            )}>
              <Car className="w-8 h-8 text-white drop-shadow-lg" />
              <div className="absolute inset-0 rounded-3xl bg-gradient-aurora opacity-30 animate-pulse" />
            </div>
            <div>
              <h1 className="text-4xl font-bold bg-gradient-aurora bg-clip-text text-transparent">
                Order a Ride
              </h1>
              <p className="text-slate-600 text-lg">Choose your preferred ride service</p>
            </div>
          </div>
        </div>

        {/* Destination Input Card with Aurora Styling */}
        <Card className="bg-glass border border-electric-blue/30 shadow-xl mb-8 backdrop-blur-lg">
          <CardHeader className="bg-gradient-to-r from-electric-blue/5 via-neon-turquoise/5 to-vivid-purple/5">
            <CardTitle className="text-slate-800 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-aurora flex items-center justify-center">
                <Clock className="w-4 h-4 text-white" />
              </div>
              Where are you going?
            </CardTitle>
            <CardDescription className="text-slate-600">
              Enter your destination to get started with any ride service.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {userLocation.latitude && (
              <div>
                <Label htmlFor="pickup" className="text-slate-700 font-medium">Your Location</Label>
                <Input 
                  id="pickup" 
                  value="Using your current location" 
                  disabled 
                  className="bg-gradient-to-r from-slate-50 to-slate-100 border-slate-300 text-slate-500"
                />
                <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                  Pickup location detected automatically
                </p>
              </div>
            )}
            
            <div>
              <Label htmlFor="destination" className="text-slate-700 font-medium">Destination</Label>
              <Input
                id="destination"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Enter destination address..."
                className="bg-white border-slate-300 text-slate-800 placeholder:text-slate-400 focus:border-electric-blue focus:ring-electric-blue/20"
              />
            </div>
          </CardContent>
        </Card>

        {/* Ride Options Grid with Aurora Colors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {rideOptions.map((service, index) => (
            <Card
              key={service.name}
              className={cn(
                "group cursor-pointer transition-all duration-500 transform hover:scale-105 hover:-translate-y-2",
                "bg-glass border border-white/30 shadow-lg hover:shadow-2xl backdrop-blur-lg overflow-hidden"
              )}
              onClick={() => handleRideSelection(service)}
            >
              <div className={cn(
                "h-32 relative overflow-hidden",
                `bg-gradient-to-br ${service.color}`,
                "group-hover:scale-110 transition-transform duration-700"
              )}>
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute top-4 right-4 opacity-60 group-hover:opacity-100 transition-opacity">
                  <ExternalLink className="w-5 h-5 text-white" />
                </div>
                <div className="absolute bottom-4 left-4 flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center">
                    {service.icon}
                  </div>
                  <div>
                    <h3 className={cn("text-xl font-bold", service.textColor)}>{service.name}</h3>
                    <p className="text-white/80 text-sm">{service.description}</p>
                  </div>
                </div>
                
                {/* Aurora shimmer effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-30 bg-gradient-aurora transition-opacity duration-500" />
              </div>
              
              <CardContent className="p-4 bg-white/95 backdrop-blur-sm">
                <div className="flex flex-wrap gap-2">
                  {service.features.map((feature, idx) => (
                    <div 
                      key={idx}
                      className={cn(
                        "px-3 py-1 rounded-full text-xs font-medium border",
                        "bg-gradient-to-r from-slate-50 to-white border-slate-200 text-slate-600"
                      )}
                    >
                      {feature}
                    </div>
                  ))}
                </div>
                
                <Button 
                  className={cn(
                    "w-full mt-4 group/btn relative overflow-hidden rounded-xl border-0 shadow-lg transition-all duration-300 transform hover:scale-105",
                    `bg-gradient-to-r ${service.color} ${service.textColor} font-semibold`
                  )}
                  onClick={(e) => {
                    e.stopPropagation();
                    handleRideSelection(service);
                  }}
                >
                  <span className="relative z-10">Select {service.name}</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000 ease-out" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Enhanced Info Section */}
        <div className="mt-8 p-6 bg-gradient-to-r from-slate-100 via-white to-slate-100 rounded-2xl border border-slate-200 shadow-lg">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-gradient-aurora flex items-center justify-center flex-shrink-0">
              <ExternalLink className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 mb-2">Quick Booking Notice</h3>
              <p className="text-slate-600 text-sm leading-relaxed">
                You will be redirected to the official website or app of your chosen service to complete your booking. 
                Make sure you have the destination address ready for the fastest booking experience.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}