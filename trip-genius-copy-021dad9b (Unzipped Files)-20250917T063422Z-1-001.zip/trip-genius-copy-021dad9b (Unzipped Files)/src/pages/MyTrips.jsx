import React, { useState, useEffect } from "react";
import { Trip } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "react-router-dom";
import { MapPin, AlertCircle, RefreshCw, Loader2 } from "lucide-react";
import TripCard from "../components/trips/TripCard";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export default function MyTrips() {
  const [trips, setTrips] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [tripToDelete, setTripToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    loadTrips();
  }, []);

  const loadTrips = async () => {
    setIsLoading(true);
    setHasError(false);
    try {
      const data = await Trip.list("-created_date");
      setTrips(data || []);
    } catch (error) {
      console.error("Error loading trips:", error);
      setHasError(true);
    }
    setIsLoading(false);
  };

  const handleRetry = () => {
    loadTrips();
  };

  const handleDeleteClick = (tripId) => {
    setTripToDelete(tripId);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (!tripToDelete) return;
    setIsDeleting(true);
    try {
      await Trip.delete(tripToDelete);
      toast.success("Trip deleted successfully.");
      loadTrips();
    } catch (error) {
      toast.error("Failed to delete trip.");
      console.error(error);
    } finally {
      setIsDeleting(false);
      setShowDeleteConfirm(false);
      setTripToDelete(null);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-light-bg flex justify-center items-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-dark-text mx-auto" />
          <span className="ml-2 text-medium-text mt-2 block">Loading your trips...</span>
        </div>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="min-h-screen bg-light-bg p-6 text-center flex items-center justify-center">
        <div>
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-dark-text mb-2">Error Loading Trips</h2>
          <p className="text-medium-text mb-6">We couldn't load your trips. Please try again.</p>
          <Button onClick={handleRetry} className="bg-black text-white hover:bg-gray-800">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen p-6 overflow-y-auto bg-light-bg pb-28">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-dark-text">My Trips</h1>
        </div>

        {trips.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-6">
            {trips.map((trip) => (
              <TripCard key={trip.id} trip={trip} onDelete={handleDeleteClick} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-light-surface rounded-xl border border-light-surface-2">
            <div className="w-24 h-24 bg-light-surface-2 rounded-full flex items-center justify-center mx-auto mb-6 border border-gray-300">
              <MapPin className="w-12 h-12 text-dark-text" />
            </div>
            <h3 className="text-2xl font-bold text-dark-text mb-4">No Trips Planned Yet</h3>
            <p className="text-medium-text mb-8 max-w-md mx-auto">
              Start planning your next adventure with our AI travel assistant.
            </p>
            <Button onClick={() => navigate("/chat")} className="bg-primary text-white hover:bg-primary-dark">
              Plan a Trip
            </Button>
          </div>
        )}
      </div>

      <AlertDialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete your trip and all of its data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
              {isDeleting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}