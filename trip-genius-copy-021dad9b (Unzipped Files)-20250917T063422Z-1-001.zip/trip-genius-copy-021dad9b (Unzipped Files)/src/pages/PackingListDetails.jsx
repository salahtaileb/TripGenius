
import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PackingList } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Loader2, ArrowLeft, Plus, Trash2, Sparkles, Pencil, Save, X } from 'lucide-react';
import { toast } from 'sonner';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import useDebounce from '@/components/hooks/useDebounce';
import { cn } from '@/lib/utils';
import { createPageUrl } from '@/utils';

const PackingListItem = ({ item, onToggle, onDelete, onUpdate }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [name, setName] = useState(item.item_name);

    const handleSave = () => {
        if (name.trim() !== item.item_name) {
            onUpdate(item.id, name.trim());
        }
        setIsEditing(false);
    };

    return (
        <div className="flex items-center gap-4 py-3 px-4 rounded-lg hover:bg-slate-50 transition-colors">
            <Checkbox
                id={`item-${item.id}`}
                checked={item.packed}
                onCheckedChange={() => onToggle(item.id)}
                className="w-5 h-5"
            />
            <div className="flex-grow">
                {isEditing ? (
                    <Input 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        onBlur={handleSave}
                        onKeyDown={(e) => e.key === 'Enter' && handleSave()}
                        className="h-8"
                        autoFocus
                    />
                ) : (
                    <label htmlFor={`item-${item.id}`} className={cn("font-medium", item.packed && "line-through text-slate-500")}>
                        {item.item_name}
                    </label>
                )}
                {item.notes && <p className="text-xs text-slate-400 mt-0.5">{item.notes}</p>}
            </div>
            {item.suggested_by_ai && !isEditing && (
                <Sparkles className="w-4 h-4 text-violet-400 flex-shrink-0" title="Suggested by AI" />
            )}
            <div className="flex gap-1">
                {isEditing ? (
                    <>
                        <Button variant="ghost" size="icon" onClick={handleSave} className="w-8 h-8"><Save className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => setIsEditing(false)} className="w-8 h-8"><X className="w-4 h-4" /></Button>
                    </>
                ) : (
                    <Button variant="ghost" size="icon" onClick={() => setIsEditing(true)} className="w-8 h-8"><Pencil className="w-4 h-4" /></Button>
                )}
                <Button variant="ghost" size="icon" onClick={() => onDelete(item.id)} className="w-8 h-8 text-slate-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></Button>
            </div>
        </div>
    );
};


export default function PackingListDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [packingList, setPackingList] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [newItemName, setNewItemName] = useState('');
  const debouncedList = useDebounce(packingList, 1000);

  const loadPackingList = useCallback(async () => {
    if (!id) {
        setError("No packing list ID provided.");
        setIsLoading(false);
        return;
    };
    setIsLoading(true);
    try {
      const data = await PackingList.get(id);
      setPackingList(data);
    } catch (err) {
      console.error("Failed to load packing list:", err);
      setError("Could not find the packing list. It may have been deleted.");
      toast.error("Failed to load packing list.");
    } finally {
      setIsLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadPackingList();
  }, [loadPackingList]);

  useEffect(() => {
    if (debouncedList && debouncedList.id && packingList) {
      // Only sync if there are actual changes
      PackingList.update(debouncedList.id, { items: debouncedList.items })
        .catch(err => {
            console.error("Failed to sync packing list:", err);
            toast.error("Failed to save changes to the cloud.");
        });
    }
  }, [debouncedList, packingList]);

  const handleTogglePacked = (itemId) => {
    setPackingList(prev => ({
      ...prev,
      items: prev.items.map(item => item.id === itemId ? { ...item, packed: !item.packed } : item)
    }));
  };

  const handleAddItem = (e) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    const newItem = {
      id: `manual-${Date.now()}`,
      item_name: newItemName.trim(),
      category: 'Miscellaneous',
      packed: false,
      quantity: 1,
      suggested_by_ai: false,
      notes: ''
    };

    setPackingList(prev => ({ ...prev, items: [...prev.items, newItem] }));
    setNewItemName('');
  };

  const handleDeleteItem = (itemId) => {
    setPackingList(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== itemId)
    }));
  };
  
  const handleUpdateItem = (itemId, newName) => {
    setPackingList(prev => ({
      ...prev,
      items: prev.items.map(item => item.id === itemId ? { ...item, item_name: newName } : item)
    }));
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-slate-500" />
        <p className="ml-2">Loading your checklist...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-slate-50 p-6 text-center">
        <div>
          <h2 className="text-xl font-bold text-red-600">Error</h2>
          <p className="text-slate-600 mt-2">{error}</p>
          <Button onClick={() => navigate(createPageUrl('PackingLists'))} className="mt-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to All Lists
          </Button>
        </div>
      </div>
    );
  }

  const packedItems = packingList.items.filter(item => item.packed).length;
  const totalItems = packingList.items.length;
  const progress = totalItems > 0 ? (packedItems / totalItems) * 100 : 0;

  const groupedItems = packingList.items.reduce((acc, item) => {
    const category = item.category || 'Miscellaneous';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {});

  const categories = Object.keys(groupedItems).sort();

  return (
    <div className="p-6 bg-gradient-to-b from-slate-50 to-white min-h-full pb-28">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Button variant="outline" onClick={() => navigate(createPageUrl('PackingLists'))} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Lists
          </Button>
          <h1 className="text-3xl font-bold text-slate-800">{packingList.name}</h1>
          <p className="text-slate-500 mt-1">{packingList.description}</p>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-2">
              <CardTitle className="text-lg">Packing Progress</CardTitle>
              <span className="font-bold text-slate-700">{packedItems} / {totalItems} Packed</span>
            </div>
            <Progress value={progress} className="w-full" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Checklist</CardTitle>
            <CardDescription>Check off items as you pack them.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddItem} className="flex gap-2 mb-4">
              <Input
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                placeholder="Add a new item..."
              />
              <Button type="submit"><Plus className="w-4 h-4 mr-2" /> Add</Button>
            </form>

            <Accordion type="multiple" defaultValue={categories} className="w-full">
              {categories.map(category => (
                <AccordionItem value={category} key={category}>
                  <AccordionTrigger className="font-semibold text-base text-slate-700">{category}</AccordionTrigger>
                  <AccordionContent>
                    <div className="divide-y">
                      {groupedItems[category].map(item => (
                        <PackingListItem
                          key={item.id}
                          item={item}
                          onToggle={handleTogglePacked}
                          onDelete={handleDeleteItem}
                          onUpdate={handleUpdateItem}
                        />
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
