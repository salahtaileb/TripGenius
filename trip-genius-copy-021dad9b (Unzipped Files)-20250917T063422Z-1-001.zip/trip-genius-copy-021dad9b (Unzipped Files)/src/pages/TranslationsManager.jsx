
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowLeft, Camera, Sparkles, Languages, ArrowRight, ExternalLink } from 'lucide-react';

export default function TranslationsManagerPage() {
  // const navigate = useNavigate(); // This is no longer needed

  const handleTranslateClick = () => {
    // Try different deep link formats
    const deepLinks = [
      'googletranslate://?op=camera',
      'googletranslate://camera',
      'googletranslate://?cam=true'
    ];
    
    // Try the first deep link
    const link = deepLinks[0];
    window.location.href = link;
    
    // If deep link fails, redirect to app store after a short delay
    setTimeout(() => {
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const isAndroid = /Android/.test(navigator.userAgent);
      
      if (isIOS) {
        window.location.href = 'https://apps.apple.com/app/google-translate/id414706506';
      } else if (isAndroid) {
        window.location.href = 'https://play.google.com/store/apps/details?id=com.google.android.apps.translate';
      }
    }, 2000);
  };

  return (
    <div className="p-6 bg-soft-white min-h-full flex items-center justify-center">
      <div className="w-full max-w-lg">
        <div className="flex items-center gap-4 mb-6">
          <Link to={createPageUrl('Home')}>
            <Button variant="outline" size="icon" className="border-gray-300 text-dark-readable hover:bg-light-grey">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
        </div>
        
        <Card className="bg-glass border border-electric-blue/20 text-center glow-electric">
          <CardHeader>
            <div className="w-20 h-20 rounded-full bg-gradient-aurora flex items-center justify-center mx-auto mb-6 animate-float glow-aurora">
              <Languages className="w-10 h-10 text-white" />
            </div>
            <CardTitle className="text-3xl font-bold text-dark-readable">
              Live Translator
            </CardTitle>
            <CardDescription className="text-lg text-neon-turquoise font-medium mt-2">
              Translate the world around you.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-medium-grey leading-relaxed">
              For instant real-world translations, use the Google Translate camera. Point it at signs, menus, and more.
            </p>
            
            <Button 
              onClick={handleTranslateClick}
              size="lg" 
              className="w-full bg-gradient-aurora text-white glow-aurora hover:scale-105 transition-transform"
            >
              <Camera className="w-5 h-5 mr-3" />
              Open Google Translate Camera
              <ArrowRight className="w-5 h-5 ml-3" />
            </Button>

            <p className="text-xs text-medium-grey px-4">
              Note: This will open the Google Translate app or redirect you to download it if not installed.
            </p>

            <div className="border-t border-white/20 pt-4 mt-6">
              <Button 
                asChild
                variant="outline" 
                size="sm" 
                className="w-full border-neon-turquoise/50 text-neon-turquoise hover:bg-neon-turquoise hover:text-white"
              >
                <a href="https://translate.google.com/" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Use Google Translate Web (Backup)
                </a>
              </Button>
            </div>

            <div className="border-t border-white/20 pt-6 mt-6">
                 <p className="text-medium-grey leading-relaxed text-sm">
                   Our own integrated "Magic Camera" feature is still under development. Stay tuned!
                 </p>
                 <div className="flex items-center justify-center gap-2 text-vivid-purple font-semibold mt-2">
                   <Sparkles className="w-5 h-5" />
                   <span>No more language barriers!</span>
                 </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
