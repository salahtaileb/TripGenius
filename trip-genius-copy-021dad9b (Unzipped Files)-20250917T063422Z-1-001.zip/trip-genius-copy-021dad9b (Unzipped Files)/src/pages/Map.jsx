import React, { useState, useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Search, X, MapPin } from 'lucide-react';
import { searchPlaces } from '@/api/functions';
import useDebounce from '../components/hooks/useDebounce';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const ChangeView = ({ center, zoom }) => {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo(center, zoom, {
        animate: true,
        duration: 1.5,
      });
    }
  }, [center, zoom, map]);
  return null;
};

export default function MapPage() {
  const [position, setPosition] = useState([20, 0]);
  const [zoom, setZoom] = useState(3);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedPlace, setSelectedPlace] = useState(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 500);
  const inputRef = useRef(null);

  useEffect(() => {
    const performSearch = async () => {
      if (debouncedSearchTerm.trim().length < 2) {
        setSearchResults([]);
        setIsSearching(false);
        return;
      }

      setIsSearching(true);
      try {
        const { data } = await searchPlaces({ query: debouncedSearchTerm });
        setSearchResults(data.results || []);
        if (!data.results || data.results.length === 0) {
          toast.info("No places found. Try a different search.");
        }
      } catch (error) {
        console.error('Search failed:', error);
        toast.error("Failed to search places. Please try again.");
        setSearchResults([]);
      } finally {
        setIsSearching(false);
      }
    };

    performSearch();
  }, [debouncedSearchTerm]);

  const handleSelectPlace = (place) => {
    setSelectedPlace(place);
    setPosition(place.coordinates);
    setZoom(13);
    setSearchTerm('');
    setSearchResults([]);
    if (inputRef.current) {
      inputRef.current.blur();
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setSearchResults([]);
    setSelectedPlace(null);
  };

  return (
    <div className="h-full w-full flex flex-col relative">
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 w-[90%] max-w-lg">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-electric-blue transition-colors" />
          <Input
            ref={inputRef}
            type="text"
            placeholder="Search for a city, place, or address..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full h-14 pl-12 pr-12 rounded-2xl shadow-lg border-2 border-slate-200/80 bg-white/80 backdrop-blur-md text-lg focus:border-electric-blue/50 focus:ring-2 focus:ring-electric-blue/20 transition-all"
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2">
            {isSearching ? (
              <Loader2 className="w-5 h-5 text-slate-500 animate-spin" />
            ) : (
              searchTerm && (
                <Button variant="ghost" size="icon" className="w-8 h-8 rounded-full" onClick={clearSearch}>
                  <X className="w-5 h-5 text-slate-500 hover:text-slate-800" />
                </Button>
              )
            )}
          </div>
        </div>

        {searchResults.length > 0 && (
          <Card className="mt-2 shadow-lg rounded-2xl bg-white/90 backdrop-blur-md border border-slate-200/50 overflow-hidden">
            <CardContent className="p-2 max-h-[50vh] overflow-y-auto">
              <ul className="space-y-1">
                {searchResults.map((place) => (
                  <li key={place.id}>
                    <button
                      onClick={() => handleSelectPlace(place)}
                      className="w-full text-left flex items-center gap-4 p-3 rounded-lg hover:bg-electric-blue/10 transition-colors"
                    >
                      <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-slate-500" />
                      </div>
                      <span className="text-slate-700 font-medium">{place.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>

      <MapContainer center={position} zoom={zoom} scrollWheelZoom={true} className="flex-grow z-0">
        <ChangeView center={position} zoom={zoom} />
        <TileLayer
          attribution='&copy; https://www.openstreetmap.org/copyright contributors &copy; https://carto.com/attributions'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />
        {selectedPlace && (
          <Marker position={selectedPlace.coordinates}>
            <Popup>{selectedPlace.name}</Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
}