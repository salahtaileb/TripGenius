import Layout from "./Layout.jsx";

import MyTrips from "./MyTrips";

import Map from "./Map";

import ViewItinerary from "./ViewItinerary";

import Profile from "./Profile";

import ExpensesTracker from "./ExpensesTracker";

import ExchangeRate from "./ExchangeRate";

import OrderCab from "./OrderCab";

import Settings from "./Settings";

import TermsConditions from "./TermsConditions";

import PrivacyPolicy from "./PrivacyPolicy";

import Home from "./Home";

import Blogs from "./Blogs";

import TravelQuiz from "./TravelQuiz";

import Deals from "./Deals";

import GetESIM from "./GetESIM";

import TranslationsManager from "./TranslationsManager";

import CreateStory from "./CreateStory";

import PhotoStoryView from "./PhotoStoryView";

import CreateTrip from "./CreateTrip";

import Chat from "./Chat";

import PackingListDetails from "./PackingListDetails";

import PackingLists from "./PackingLists";

import Notifications from "./Notifications";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    MyTrips: MyTrips,
    
    Map: Map,
    
    ViewItinerary: ViewItinerary,
    
    Profile: Profile,
    
    ExpensesTracker: ExpensesTracker,
    
    ExchangeRate: ExchangeRate,
    
    OrderCab: OrderCab,
    
    Settings: Settings,
    
    TermsConditions: TermsConditions,
    
    PrivacyPolicy: PrivacyPolicy,
    
    Home: Home,
    
    Blogs: Blogs,
    
    TravelQuiz: TravelQuiz,
    
    Deals: Deals,
    
    GetESIM: GetESIM,
    
    TranslationsManager: TranslationsManager,
    
    CreateStory: CreateStory,
    
    PhotoStoryView: PhotoStoryView,
    
    CreateTrip: CreateTrip,
    
    Chat: Chat,
    
    PackingListDetails: PackingListDetails,
    
    PackingLists: PackingLists,
    
    Notifications: Notifications,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<MyTrips />} />
                
                
                <Route path="/MyTrips" element={<MyTrips />} />
                
                <Route path="/Map" element={<Map />} />
                
                <Route path="/ViewItinerary" element={<ViewItinerary />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/ExpensesTracker" element={<ExpensesTracker />} />
                
                <Route path="/ExchangeRate" element={<ExchangeRate />} />
                
                <Route path="/OrderCab" element={<OrderCab />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/TermsConditions" element={<TermsConditions />} />
                
                <Route path="/PrivacyPolicy" element={<PrivacyPolicy />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Blogs" element={<Blogs />} />
                
                <Route path="/TravelQuiz" element={<TravelQuiz />} />
                
                <Route path="/Deals" element={<Deals />} />
                
                <Route path="/GetESIM" element={<GetESIM />} />
                
                <Route path="/TranslationsManager" element={<TranslationsManager />} />
                
                <Route path="/CreateStory" element={<CreateStory />} />
                
                <Route path="/PhotoStoryView" element={<PhotoStoryView />} />
                
                <Route path="/CreateTrip" element={<CreateTrip />} />
                
                <Route path="/Chat" element={<Chat />} />
                
                <Route path="/PackingListDetails" element={<PackingListDetails />} />
                
                <Route path="/PackingLists" element={<PackingLists />} />
                
                <Route path="/Notifications" element={<Notifications />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}