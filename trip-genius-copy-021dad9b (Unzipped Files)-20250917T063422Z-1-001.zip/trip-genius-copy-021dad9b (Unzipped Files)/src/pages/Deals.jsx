import React from 'react';
import { Sparkles, Tag } from 'lucide-react';

export default function DealsPage() {
  return (
    <div className="p-4 md:p-6 min-h-full">
      <div className="flex items-center gap-3 mb-6">
        <Sparkles className="w-8 h-8 text-slate-800" />
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 whitespace-nowrap">Exclusive Travel Deals</h1>
      </div>
      
      <p className="text-lg text-slate-600 mb-8 max-w-3xl">
        Discover hand-picked deals on hotels and accommodations worldwide. Find the perfect stay for your budget.
      </p>

      <div className="text-center py-20 bg-light-surface rounded-xl border border-light-surface-2">
        <div className="w-24 h-24 bg-light-surface-2 rounded-full flex items-center justify-center mx-auto mb-6 border border-gray-300">
          <Tag className="w-12 h-12 text-dark-text" />
        </div>
        <h3 className="text-2xl font-bold text-dark-text mb-4">Deals Coming Soon!</h3>
        <p className="text-medium-text mb-8 max-w-md mx-auto">
          We're working hard to curate the best travel deals for you. Check back soon for exclusive offers.
        </p>
      </div>
    </div>
  );
}