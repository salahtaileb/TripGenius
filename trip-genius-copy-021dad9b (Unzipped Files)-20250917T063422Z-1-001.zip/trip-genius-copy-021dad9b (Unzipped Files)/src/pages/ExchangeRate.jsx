import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Loader2, ArrowRightLeft, AlertCircle, Lightbulb, CreditCard, Banknote, Shield, TrendingUp } from 'lucide-react';
import { getExchangeRates } from '@/api/functions';
import { toast } from 'sonner';

// A curated list of common currencies
const popularCurrencies = [
  'USD', 'EUR', 'JPY', 'GBP', 'AUD', 'CAD', 'CHF', 'CNY', 'SEK', 'NZD',
  'MXN', 'SGD', 'HKD', 'NOK', 'KRW', 'TRY', 'RUB', 'INR', 'BRL', 'ZAR'
];

const currencyTips = [
  {
    icon: <CreditCard className="w-5 h-5" />,
    title: "Use Your Bank Card Wisely",
    description: "Many banks charge foreign transaction fees. Look for travel-friendly cards with no foreign fees and competitive exchange rates.",
    color: "from-blue-500 to-indigo-600"
  },
  {
    icon: <Banknote className="w-5 h-5" />,
    title: "Avoid Airport Exchanges",
    description: "Airport currency exchanges typically offer poor rates. Exchange a small amount for immediate needs, then find better rates in the city.",
    color: "from-amber-500 to-orange-600"
  },
  {
    icon: <Shield className="w-5 h-5" />,
    title: "ATMs Often Give Best Rates",
    description: "Local ATMs usually offer better exchange rates than currency exchange counters. Just watch out for ATM fees from your bank.",
    color: "from-green-500 to-emerald-600"
  },
  {
    icon: <TrendingUp className="w-5 h-5" />,
    title: "Monitor Rate Trends",
    description: "Exchange rates fluctuate daily. If you're planning ahead, monitor trends and exchange when rates are favorable.",
    color: "from-purple-500 to-violet-600"
  }
];

export default function ExchangeRatePage() {
  const navigate = useNavigate();
  const [rates, setRates] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const [amount, setAmount] = useState('100');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('EUR');
  const [convertedAmount, setConvertedAmount] = useState('');

  const fetchRates = useCallback(async (base) => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await getExchangeRates({ baseCurrency: base });
      if (response.data && response.data.rates) {
        setRates(response.data.rates);
        toast.success(`Updated rates for ${base}`);
      } else {
        throw new Error(response.data?.error || 'Failed to fetch exchange rates.');
      }
    } catch (err) {
      setError(err.message);
      toast.error(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRates(fromCurrency);
  }, [fromCurrency, fetchRates]);

  useEffect(() => {
    if (rates && rates[toCurrency]) {
      const rate = rates[toCurrency];
      const result = (parseFloat(amount) * rate).toFixed(2);
      setConvertedAmount(result);
    }
  }, [amount, toCurrency, rates]);

  const handleSwapCurrencies = () => {
    const temp = fromCurrency;
    setFromCurrency(toCurrency);
    setToCurrency(temp);
  };
  
  const handleAmountChange = (e) => {
    const value = e.target.value;
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
    }
  };

  return (
    <div className="p-4 md:p-6 min-h-full bg-light-bg pb-32">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" size="icon" className="border-gray-300 text-dark-text hover:bg-gray-100" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-3xl font-bold text-dark-text">Exchange Rate Converter</h1>
        </div>

        <Card className="bg-white border-light-surface-2 shadow-lg mb-8">
          <CardHeader>
            <CardTitle>Real-Time Currency Conversion</CardTitle>
            <CardDescription>Get the latest foreign exchange rates.</CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6" role="alert">
                <div className="flex">
                  <AlertCircle className="h-5 w-5 text-red-500 mr-3" />
                  <div>
                    <p className="font-bold">Error</p>
                    <p>{error}</p>
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input id="amount" value={amount} onChange={handleAmountChange} className="text-lg bg-white border-gray-300" />
              </div>
              
              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="from">From</Label>
                <Select id="from" value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger className="text-lg bg-white border-gray-300">
                    <SelectValue placeholder="From currency" />
                  </SelectTrigger>
                  <SelectContent className="bg-white">
                    {popularCurrencies.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-center">
                <Button variant="ghost" size="icon" onClick={handleSwapCurrencies} className="h-10 w-10">
                  <ArrowRightLeft className="w-5 h-5 text-gray-500" />
                </Button>
              </div>
            </div>

            <div className="mt-6">
              <Label>To</Label>
              <Select value={toCurrency} onValueChange={setToCurrency}>
                <SelectTrigger className="text-lg bg-white border-gray-300">
                  <SelectValue placeholder="To currency" />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  {popularCurrencies.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            
            <div className="mt-8 text-center bg-light-surface p-6 rounded-lg border border-light-surface-2">
              <p className="text-lg text-medium-text">Converted Amount</p>
              {isLoading ? (
                <Loader2 className="w-8 h-8 animate-spin text-dark-text mx-auto mt-2" />
              ) : (
                <p className="text-4xl font-bold text-dark-text mt-2">
                  {convertedAmount ? `${convertedAmount} ${toCurrency}` : '-.--'}
                </p>
              )}
              {rates && rates[toCurrency] && (
                <p className="text-sm text-medium-text mt-2">
                  1 {fromCurrency} = {rates[toCurrency].toFixed(4)} {toCurrency}
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Currency Exchange Tips Section */}
        <Card className="bg-gradient-to-r from-slate-50 to-white border border-slate-200 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-slate-800">
              <div className="w-10 h-10 rounded-full bg-yellow-100 flex items-center justify-center">
                <Lightbulb className="w-5 h-5 text-yellow-600" />
              </div>
              Smart Currency Exchange Tips
            </CardTitle>
            <CardDescription>
              Save money and avoid common pitfalls when exchanging currency abroad.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {currencyTips.map((tip, index) => (
                <div 
                  key={index} 
                  className="flex gap-4 p-4 bg-white rounded-xl border border-slate-200 hover:shadow-md transition-all duration-300"
                >
                  <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${tip.color} flex items-center justify-center text-white flex-shrink-0`}>
                    {tip.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-800 mb-2">{tip.title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">{tip.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-4 bg-blue-50 rounded-xl border border-blue-200">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-blue-900 mb-1">Pro Tip</h4>
                  <p className="text-sm text-blue-800 leading-relaxed">
                    Always decline dynamic currency conversion (DCC) when paying with a card abroad. 
                    Let your bank handle the conversion for better rates and lower fees.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}