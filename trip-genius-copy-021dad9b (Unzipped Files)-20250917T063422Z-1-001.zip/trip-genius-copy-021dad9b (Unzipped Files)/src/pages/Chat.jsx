
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, Send, User, Loader2, Camera, Plane, MapPin, Save, Map as MapIcon } from 'lucide-react';
import { aiChat } from '@/api/functions';
import { User as UserEntity } from '@/api/entities';
import { Trip } from '@/api/entities';
import { TravelProfile } from '@/api/entities';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { cn } from '@/lib/utils';

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSavingTrip, setIsSavingTrip] = useState(null); // Use a unique identifier for saving state
  const [user, setUser] = useState(null);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [hasCompletedQuiz, setHasCompletedQuiz] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    UserEntity.me().then(setUser).catch(console.error);
    
    // Check if user just returned from quiz
    const urlParams = new URLSearchParams(window.location.search);
    const fromQuiz = urlParams.get('fromQuiz');
    if (fromQuiz === 'true') {
      setTimeout(() => {
        setMessages([{
          role: 'assistant',
          content: `Welcome back! I see you've completed your travel style quiz. Now I can give you much more personalized recommendations. What kind of trip are you thinking about?`
        }]);
      }, 500);
      
      // Clean up URL
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  useEffect(() => {
    // Check if user has completed travel profile
    const checkTravelProfile = async () => {
      if (user) {
        try {
          const profiles = await TravelProfile.filter({ user_email: user.email });
          const hasProfile = profiles && profiles.length > 0;
          setHasCompletedQuiz(hasProfile);
        } catch (error) {
          console.error('Error checking travel profile:', error);
          setHasCompletedQuiz(false);
        }
      }
    };
    
    checkTravelProfile();
  }, [user]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const submitMessage = async (messageContent) => {
    if (!messageContent.trim() || isLoading) return;

    const userMessage = { role: 'user', content: messageContent.trim() };
    
    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);

    try {
      // --- FIX: Ensure only messages with text `content` are sent in history ---
      const conversationHistory = messages.map(msg => ({
        role: msg.role,
        content: msg.content // This will be undefined for trip_plan messages, which is fine as they won't be sent to AI
      })).filter(msg => msg.content); // Exclude messages without a 'content' property from history

      const response = await aiChat({
        message: userMessage.content,
        conversationHistory
      });

      if (response.data.error) {
        throw new Error(response.data.error);
      }
      
      if (response.data.type === 'trip_plan') {
        setMessages(prev => [...prev, {
          role: 'assistant',
          type: 'trip_plan',
          data: response.data.data
        }]);
      } else {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: response.data.message
        }]);
      }

    } catch (error) {
      console.error('Chat error:', error);
      toast.error('Failed to get AI response. Please try again.');
      
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "I apologize, but I'm having trouble responding right now. Please try asking again!"
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    submitMessage(inputMessage);
  };
  
  const handleCameraAction = () => {
    fileInputRef.current?.click();
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploadingPhoto(true);
    
    try {
      setMessages(prev => [...prev, {
        role: 'user',
        content: `📸 Analyzing photo...`,
        isPhotoUpload: true
      }]);

      const { UploadFile } = await import('@/api/integrations');
      const { file_url } = await UploadFile({ file });
      
      await submitMessage(`I just uploaded a photo. Please analyze this travel photo and give me recommendations based on what you see. Here's the image: ${file_url}`);
      
    } catch (error) {
      console.error('Photo upload error:', error);
      toast.error('Failed to upload photo. Please try again.');
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "Oops! There was an issue uploading your photo. Please try again."
      }]);
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };
  
  const handleSaveTrip = async (tripData, tempId) => {
    setIsSavingTrip(tempId);
    toast.info("Saving your new trip...", {
      description: `"${tripData.name}" is being added to 'My Trips'.`,
    });

    try {
      const newTrip = await Trip.create({
        ...tripData,
        generated_by_ai: true,
        ai_prompt_used: messages.findLast(m => m.role === 'user')?.content || 'Unknown',
      });
      
      toast.success("Trip saved successfully!", {
        description: "Redirecting you to the full itinerary...",
      });
      
      navigate(createPageUrl(`ViewItinerary?id=${newTrip.id}`));

    } catch (error) {
      console.error("Failed to save trip:", error);
      toast.error("Failed to save trip", {
        description: "Something went wrong. Please try again.",
      });
      setIsSavingTrip(null);
    }
  };

  const handleActivitiesAction = () => {
    toast.info("The booking engine is temporarily disabled.");
  };

  const handlePlanTripAction = () => {
    // Navigate to the Create Trip page to input specific details
    navigate(createPageUrl('CreateTrip'));
  };

  return (
    <div className="h-full flex flex-col bg-light-bg">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handlePhotoUpload}
        accept="image/*"
        className="hidden"
        capture="environment"
      />
      
      <div className="flex-1 overflow-y-auto p-4 pb-36"> {/* Increased padding to make space for the fixed input */}
        <div className="max-w-4xl mx-auto">
          {messages.length === 0 && (
            <div className="text-center pt-12">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68bd2aaad0d49bd830ae5c40/e5d85c431_image.png"
                alt="TripGenius Genie"
                className="w-24 h-auto mx-auto mb-4"
              />
              <h2 className="text-xl font-bold text-dark-text mb-2">
                Where to today {user?.full_name?.split(' ')[0] || 'traveler'}?
              </h2>
              <p className="text-sm text-medium-text max-w-sm mx-auto mb-8">
                I'm your TripGenius AI assistant. Let's plan your next adventure!
              </p>
              
              <div className="flex justify-center gap-4">
                  <Button 
                    variant="outline" 
                    className={cn(
                        "flex-col h-20 w-24 border-2 border-slate-300 text-xs rounded-xl backdrop-blur-sm bg-white/50",
                        "transition-all duration-300 hover:scale-105 hover:border-electric-blue/80 hover:shadow-lg"
                    )}
                    onClick={handleCameraAction}
                    disabled={isUploadingPhoto || isLoading}
                  >
                      {isUploadingPhoto ? <Loader2 className="w-6 h-6 mb-1.5 animate-spin text-slate-500"/> : <Camera className="w-6 h-6 mb-1.5 text-electric-blue"/>}
                      <span className="font-semibold leading-tight text-slate-700">Camera</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className={cn(
                        "flex-col h-20 w-24 border-2 border-slate-300 text-xs rounded-xl backdrop-blur-sm bg-white/50",
                        "transition-all duration-300 hover:scale-105 hover:border-vivid-purple/80 hover:shadow-lg"
                    )}
                    onClick={handlePlanTripAction}
                    disabled={isLoading}
                  >
                      <Plane className="w-6 h-6 mb-1.5 text-vivid-purple"/>
                      <span className="font-semibold leading-tight text-slate-700">Plan Trip</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className={cn(
                        "flex-col h-20 w-24 border-2 border-slate-300 text-xs rounded-xl backdrop-blur-sm bg-white/50",
                        "transition-all duration-300 hover:scale-105 hover:border-neon-pink/80 hover:shadow-lg"
                    )}
                    onClick={handleActivitiesAction}
                    disabled={isLoading}
                  >
                      <MapPin className="w-6 h-6 mb-1.5 text-neon-pink"/>
                      <span className="font-semibold leading-tight text-slate-700">Activities</span>
                  </Button>
              </div>
            </div>
          )}

          <div className="space-y-4 pt-4">
            {messages.map((message, index) => {
              if (message.type === 'trip_plan' && message.data) {
                // This is a special card for the generated trip plan
                const tempId = `trip-${index}`;
                const isThisSaving = isSavingTrip === tempId;
                return (
                  <div key={index} className="flex gap-3 justify-start">
                    <div className="w-8 h-8 rounded-full bg-black flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <Card className="bg-white border-light-surface-2 max-w-[80%] overflow-hidden">
                      <div className="h-32 bg-cover bg-center" style={{backgroundImage: `url(${message.data.cover_image_url})`}}></div>
                      <CardContent className="p-4">
                        <p className="font-bold text-dark-text text-lg">{message.data.name}</p>
                        <p className="text-medium-text text-sm mb-4">{message.data.overview?.description}</p>
                        <Button 
                          onClick={() => handleSaveTrip(message.data, tempId)}
                          disabled={isSavingTrip !== null}
                          className="w-full bg-black text-white hover:bg-gray-800"
                        >
                          {isThisSaving ? (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          ) : (
                            <Save className="w-4 h-4 mr-2" />
                          )}
                          {isThisSaving ? 'Saving...' : 'Save & View Trip'}
                        </Button>
                      </CardContent>
                    </Card>
                  </div>
                );
              }
              
              // This is the normal message bubble
              return (
                <div key={index} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`flex gap-3 max-w-[80%] ${message.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user' 
                        ? 'bg-gray-200' 
                        : 'bg-black'
                    }`}>
                      {message.role === 'user' ? (
                        <User className="w-5 h-5 text-dark-text" />
                      ) : (
                        <Sparkles className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <Card className={`${
                      message.role === 'user' 
                        ? 'bg-gray-100 border-gray-200' 
                        : 'bg-white border-light-surface-2'
                    }`}>
                      <CardContent className="p-3">
                        <p className="text-dark-text whitespace-pre-wrap">{message.content}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              );
            })}
            
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-black flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <Card className="bg-white border-light-surface-2">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-dark-text" />
                      <span className="text-medium-text">Thinking...</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      </div>

      <div className="fixed bottom-20 left-0 right-0 z-10 p-2 border-t border-slate-200 bg-white/90 backdrop-blur-md">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleFormSubmit} className="flex gap-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Ask me about destinations, itineraries, travel tips..."
              disabled={isLoading || isUploadingPhoto}
              className="flex-1 bg-white border-gray-300 text-dark-text h-10"
            />
            <Button 
              type="submit" 
              disabled={isLoading || !inputMessage.trim() || isUploadingPhoto}
              className="bg-black text-white hover:bg-gray-800 h-10 w-10"
              size="icon"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
