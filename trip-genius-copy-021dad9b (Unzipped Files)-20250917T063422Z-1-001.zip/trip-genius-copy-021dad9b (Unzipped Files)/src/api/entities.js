import { base44 } from './base44Client';


export const Trip = base44.entities.Trip;

export const Affiliate = base44.entities.Affiliate;

export const Share = base44.entities.Share;

export const TravelProfile = base44.entities.TravelProfile;

export const Translation = base44.entities.Translation;

export const PhotoStory = base44.entities.PhotoStory;

export const PackingList = base44.entities.PackingList;

export const Expense = base44.entities.Expense;

export const Notification = base44.entities.Notification;



// auth sdk:
export const User = base44.auth;