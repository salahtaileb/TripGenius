import { base44 } from './base44Client';


export const getMapboxToken = base44.functions.getMapboxToken;

export const searchPlaces = base44.functions.searchPlaces;

export const getExchangeRates = base44.functions.getExchangeRates;

export const aiChat = base44.functions.aiChat;

export const getAffiliateTokens = base44.functions.getAffiliateTokens;

export const generatePackingList = base44.functions.generatePackingList;

export const generateTripPlan = base44.functions.generateTripPlan;

export const analyzeExpenses = base44.functions.analyzeExpenses;

